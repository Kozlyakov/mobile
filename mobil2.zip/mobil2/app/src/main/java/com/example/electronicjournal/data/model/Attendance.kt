package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance")
data class Attendance(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val studentId: Int,
    val subjectId: Int,
    val date: String, // Формат: "yyyy-MM-dd"
    val lessonNumber: Int, // Номер урока (1-8)
    val isPresent: Boolean = true,
    val reason: String? = null // Причина отсутствия: "болезнь", "семейные обстоятельства" и т.д.
)
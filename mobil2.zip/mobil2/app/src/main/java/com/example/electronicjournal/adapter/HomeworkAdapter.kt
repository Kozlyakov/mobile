package com.example.electronicjournal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.electronicjournal.R
import com.example.electronicjournal.data.model.Homework

class HomeworkAdapter(
    private var homeworkWithSubjects: List<Pair<Homework, String>>,
    private val userType: String = "student"
) : RecyclerView.Adapter<HomeworkAdapter.HomeworkViewHolder>() {

    var onHomeworkClick: (Int) -> Unit = {}
    var onMarkDoneClick: (Int) -> Unit = {}

    class HomeworkViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubject)
        val tvAssignmentDate: TextView = itemView.findViewById(R.id.tvAssignmentDate)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        val tvDueDate: TextView = itemView.findViewById(R.id.tvDueDate)
        val btnEdit: View? = itemView.findViewById(R.id.btnEdit)
        val btnCheck: View? = itemView.findViewById(R.id.btnCheck)
        val btnDelete: View? = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeworkViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_homework, parent, false)
        return HomeworkViewHolder(view)
    }

    override fun onBindViewHolder(holder: HomeworkViewHolder, position: Int) {
        val (homework, subjectName) = homeworkWithSubjects[position]

        holder.tvSubject.text = subjectName
        holder.tvAssignmentDate.text = "Задано: ${homework.assignmentDate}"
        holder.tvDueDate.text = "Сдать до: ${homework.dueDate}"
        holder.tvDescription.text = homework.description
        holder.tvStatus.text = if (homework.isCompleted) "Выполнено" else "Активно"

        holder.itemView.setOnClickListener {
            onHomeworkClick(homework.id)
        }

        holder.btnCheck?.setOnClickListener {
            onMarkDoneClick(homework.id)
        }
    }

    override fun getItemCount(): Int = homeworkWithSubjects.size

    fun updateData(data: List<Pair<Homework, String>>) {
        homeworkWithSubjects = data
        notifyDataSetChanged()
    }
}

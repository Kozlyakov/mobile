package com.example.electronicjournal.ui.teacher

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.electronicjournal.R
import com.example.electronicjournal.data.database.AppDatabase
import com.example.electronicjournal.data.repository.ScheduleRepository
import com.example.electronicjournal.databinding.FragmentTeacherDashboardBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class TeacherDashboardFragment : Fragment() {

    private var _binding: FragmentTeacherDashboardBinding? = null
    private val binding get() = _binding!!
    private lateinit var database: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTeacherDashboardBinding.inflate(inflater, container, false)
        database = AppDatabase.getInstance(requireContext())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()
        setupClickListeners()
        loadData()
    }

    private fun setupUI() {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        binding.tvDate.text = dateFormat.format(Date())
    }

    private fun setupClickListeners() {
        binding.btnQuickGrade.setOnClickListener {
            findNavController().navigate(R.id.action_to_gradeAssignment)
        }

        binding.btnQuickHomework.setOnClickListener {
            findNavController().navigate(R.id.action_to_homeworkCreation)
        }

        binding.btnQuickAttendance.setOnClickListener {
            findNavController().navigate(R.id.action_to_attendance)
        }

        binding.cardStudentGrades.setOnClickListener {
            findNavController().navigate(R.id.action_to_studentGrades)
        }

        binding.cardHomework.setOnClickListener {
            findNavController().navigate(R.id.action_to_homeworkList)
        }

        binding.cardAttendance.setOnClickListener {
            findNavController().navigate(R.id.action_to_attendanceOverview)
        }
    }

    private fun loadData() {
        // Корректно привязано к жизненному циклу view
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val scheduleRepository = ScheduleRepository(database.scheduleDao())
                val currentDayOfWeek = getCurrentDayOfWeek()

                scheduleRepository
                    .getScheduleByClassAndDay(1, currentDayOfWeek)
                    .collectLatest { lessons ->

                        val b = _binding ?: return@collectLatest

                        if (lessons.isNotEmpty()) {
                            b.tvTodayLessons.text = "Сегодня ${lessons.size} уроков:"
                            val firstLesson = lessons.first()
                            b.tvNextLesson.text =
                                "${firstLesson.subject} (${firstLesson.classroom})"

                            if (lessons.size > 1) {
                                val secondLesson = lessons[1]
                                b.tvNextLessonTime.text =
                                    "Следующий: ${secondLesson.subject} в ${
                                        getLessonTime(
                                            secondLesson.lessonNumber
                                        )
                                    }"
                            } else {
                                b.tvNextLessonTime.text = "Это последний урок"
                            }
                        } else {
                            b.tvTodayLessons.text = "Сегодня уроков нет"
                            b.tvNextLesson.text = "Свободный день"
                            b.tvNextLessonTime.text = ""
                        }
                    }
            } catch (e: Exception) {
                val b = _binding ?: return@launch
                b.tvTodayLessons.text = "Ошибка загрузки расписания"
                b.tvNextLesson.text = ""
                b.tvNextLessonTime.text = ""
            }
        }
    }

    private fun getCurrentDayOfWeek(): Int {
        val calendarDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        return when (calendarDay) {
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            Calendar.SUNDAY -> 7
            else -> 1
        }
    }

    private fun getLessonTime(lessonNumber: Int): String {
        val lessonTimes = mapOf(
            1 to "8:30-9:15",
            2 to "9:25-10:10",
            3 to "10:20-11:05",
            4 to "11:20-12:05",
            5 to "12:20-13:05",
            6 to "13:15-14:00",
            7 to "14:10-14:55",
            8 to "15:05-15:50"
        )
        return lessonTimes[lessonNumber] ?: ""
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.Lesson
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonDao {

    @Query("SELECT * FROM lessons WHERE className = :className AND dayOfWeek = :dayOfWeek ORDER BY lessonNumber")
    fun getLessonsByClassAndDay(className: String, dayOfWeek: Int): Flow<List<Lesson>>

    @Query("SELECT * FROM lessons WHERE className = :className ORDER BY dayOfWeek, lessonNumber")
    fun getLessonsByClass(className: String): Flow<List<Lesson>>

    @Query("SELECT * FROM lessons WHERE teacherId = :teacherId AND dayOfWeek = :dayOfWeek ORDER BY lessonNumber")
    fun getTeacherLessonsByDay(teacherId: Int, dayOfWeek: Int): Flow<List<Lesson>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLesson(lesson: Lesson)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllLessons(lessons: List<Lesson>)

    @Update
    suspend fun updateLesson(lesson: Lesson)

    @Query("DELETE FROM lessons WHERE id = :lessonId")
    suspend fun deleteLesson(lessonId: Int)

    @Query("DELETE FROM lessons WHERE className = :className")
    suspend fun deleteLessonsByClass(className: String)
}
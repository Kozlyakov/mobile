package com.example.electronicjournal.ui.teacher

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.electronicjournal.data.database.AppDatabase
import com.example.electronicjournal.data.model.Grade
import com.example.electronicjournal.data.model.Student
import com.example.electronicjournal.data.repository.StudentRepository
import com.example.electronicjournal.databinding.FragmentGradeAssignmentBinding
import com.example.electronicjournal.ui.teacher.adapters.StudentGradesTableAdapter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class GradeAssignmentFragment : Fragment() {

    private var _binding: FragmentGradeAssignmentBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: StudentGradesTableAdapter
    private lateinit var database: AppDatabase
    private lateinit var studentRepository: StudentRepository

    // Временное хранилище для новых оценок
    private val newGrades = mutableMapOf<Int, MutableList<Int>>() // studentId -> list of grades

    // Текущий предмет для выставления оценок
    private val currentSubjectId = 1 // Математика
    private val currentSubjectName = "Математика"
    private val currentClassName = "10А"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentGradeAssignmentBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = AppDatabase.getInstance(requireContext())
        studentRepository = StudentRepository(database.studentDao())

        setupRecyclerView()
        setupClickListeners()
        updateSubjectInfo()
        loadStudents()
    }

    private fun setupRecyclerView() {
        adapter = StudentGradesTableAdapter()

        // Обработчик кликов по оценкам
        adapter.onGradeClick = { student, _ ->
            showGradeDialog(student)
        }

        // Обработчик кликов по посещаемости (можно отключить для этого фрагмента)
        adapter.onAttendanceClick = { _, _ ->
            // Не делаем ничего в этом фрагменте
        }

        binding.rvStudents.layoutManager = LinearLayoutManager(requireContext())
        binding.rvStudents.adapter = adapter
    }

    private fun setupClickListeners() {
        binding.btnSaveGrades.setOnClickListener {
            saveGrades()
        }

        binding.btnBack.setOnClickListener {
            // Используем навигацию вместо простого возврата
            findNavController().navigateUp()
        }
    }

    private fun loadStudents() {
        lifecycleScope.launch {
            try {
                // Загрузка реальных учеников из базы
                val students = studentRepository.getStudentsByClass(currentClassName).first()

                if (students.isNotEmpty()) {
                    // Загружаем существующие оценки для отображения
                    val existingGrades = mutableMapOf<Int, List<Int>>()
                    val attendance = students.associate { it.id to true }

                    students.forEach { student ->
                        // ЗАГРУЖАЕМ ОЦЕНКИ ИЗ БАЗЫ ДАННЫХ
                        val studentGrades = database.gradeDao()
                            .getGradesByStudentAndSubject(student.id, currentSubjectId).first()
                        existingGrades[student.id] = studentGrades.map { it.grade }
                    }

                    if (_binding != null) {
                        adapter.updateData(students, existingGrades, attendance)
                        updateSubjectInfo()
                    }
                } else {
                    loadDemoStudents()
                }
            } catch (e: Exception) {
                if (_binding != null) {
                    loadDemoStudents()
                }
            }
        }
    }

    private fun loadDemoStudents() {
        if (_binding == null) return

        // Демо-данные на случай ошибки загрузки из базы
        val students = listOf(
            Student(1, "Иванов Алексей", currentClassName, "ivanov@school.ru"),
            Student(2, "Петрова Мария", currentClassName, "petrova@school.ru"),
            Student(3, "Сидоров Дмитрий", currentClassName, "sidorov@school.ru"),
            Student(4, "Козлова Анна", currentClassName, "kozlova@school.ru"),
            Student(5, "Николаев Иван", currentClassName, "nikolaev@school.ru")
        )

        val initialGrades = students.associate { it.id to emptyList<Int>() }
        val initialAttendance = students.associate { it.id to true }

        adapter.updateData(students, initialGrades, initialAttendance)
        updateSubjectInfo()
    }

    private fun updateSubjectInfo() {
        if (_binding == null) return

        binding.tvSubject.text = "$currentSubjectName - $currentClassName класс"
        binding.tvDate.text = "Сегодня, ${getCurrentDateFormatted()}"
    }

    private fun showGradeDialog(student: Student) {
        val grades = arrayOf("2", "3", "4", "5", "Удалить оценку")

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Оценка для ${student.name}")
            .setItems(grades) { _, which ->
                when (which) {
                    4 -> {
                        // Удаление последней оценки
                        removeLastGrade(student.id)
                    }
                    else -> {
                        val selectedGrade = grades[which].toInt()
                        addGrade(student, selectedGrade)
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun addGrade(student: Student, grade: Int) {
        if (_binding == null) return

        // Добавляем оценку в адаптер для отображения
        adapter.updateGrade(student.id, grade)

        // Сохраняем во временное хранилище
        if (!newGrades.containsKey(student.id)) {
            newGrades[student.id] = mutableListOf()
        }
        newGrades[student.id]?.add(grade)

        updateUI()

        // Показываем подтверждение
        android.widget.Toast.makeText(
            requireContext(),
            "Оценка $grade выставлена для ${student.name}",
            android.widget.Toast.LENGTH_SHORT
        ).show()
    }

    private fun removeLastGrade(studentId: Int) {
        if (_binding == null) return

        // Удаляем последнюю оценку из адаптера
        val currentGrades = adapter.getGrades()[studentId]?.toMutableList() ?: mutableListOf()
        if (currentGrades.isNotEmpty()) {
            currentGrades.removeLast()
            val updatedGrades = adapter.getGrades().toMutableMap()
            updatedGrades[studentId] = currentGrades
            adapter.updateData(adapter.getStudents(), updatedGrades, adapter.getAttendance())

            // Удаляем из временного хранилища
            newGrades[studentId]?.removeLastOrNull()

            android.widget.Toast.makeText(
                requireContext(),
                "Последняя оценка удалена",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
        updateUI()
    }

    private fun saveGrades() {
        if (_binding == null) return

        if (newGrades.isNotEmpty()) {
            lifecycleScope.launch {
                try {
                    val date = getCurrentDateForDatabase()
                    var savedCount = 0

                    newGrades.forEach { (studentId, gradesList) ->
                        gradesList.forEach { grade ->
                            val newGrade = Grade(
                                studentId = studentId,
                                subjectId = currentSubjectId,
                                grade = grade,
                                gradeType = "ответ",
                                date = date,
                                comment = "Выставлено в быстром режиме"
                            )
                            database.gradeDao().insertGrade(newGrade)
                            savedCount++
                        }
                    }

                    android.widget.Toast.makeText(
                        requireContext(),
                        "✅ Сохранено $savedCount оценок для ${newGrades.size} учеников",
                        android.widget.Toast.LENGTH_LONG
                    ).show()

                    // Очищаем временное хранилище
                    newGrades.clear()

                    // НАВИГАЦИЯ ОБРАТНО К ТАБЛИЦЕ ОЦЕНОК
                    // Используем navigateUp для возврата к предыдущему фрагменту
                    // который должен быть StudentGradesTableFragment
                    findNavController().navigateUp()

                } catch (e: Exception) {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "❌ Ошибка сохранения: ${e.message}",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
        } else {
            android.widget.Toast.makeText(
                requireContext(),
                "ℹ️ Нет новых оценок для сохранения",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun updateUI() {
        if (_binding == null) return

        val totalGrades = newGrades.values.sumOf { it.size }

        // Обновляем текст кнопки сохранения
        binding.btnSaveGrades.text = if (totalGrades > 0) {
            "Сохранить оценки ($totalGrades)"
        } else {
            "Сохранить оценки"
        }

        // Включаем/выключаем кнопку в зависимости от наличия оценок
        binding.btnSaveGrades.isEnabled = totalGrades > 0
    }

    private fun getCurrentDateForDatabase(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(Date())
    }

    private fun getCurrentDateFormatted(): String {
        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        return dateFormat.format(Date())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
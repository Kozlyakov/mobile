package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.ScheduleDao
import com.example.electronicjournal.data.model.Schedule
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ScheduleRepository(private val scheduleDao: ScheduleDao) {

    // Получить расписание по классу и дню недели
    fun getScheduleByClassAndDay(classId: Int, dayOfWeek: Int): Flow<List<Schedule>> {
        return scheduleDao.getScheduleByClassAndDay(classId, dayOfWeek)
    }

    // Удалить всё расписание
    suspend fun deleteAll() {
        scheduleDao.deleteAllSchedules()
    }

    // Добавить список уроков
    suspend fun insertAll(list: List<Schedule>) {
        scheduleDao.insertAllSchedules(list)
    }

    // Добавить один урок
    suspend fun insertLesson(lesson: Schedule) {
        scheduleDao.addLesson(lesson)
    }

    // Удалить урок
    suspend fun deleteLesson(id: Int) {
        scheduleDao.deleteLesson(id)
    }

    // Инициализация тестового расписания
    suspend fun initializeSampleData() {
        deleteAll()

        val sample = listOf(
            Schedule(classId = 1, subject = "Математика", teacher = "Сидорова А.С.", dayOfWeek = 1, lessonNumber = 1, classroom = "301"),
            Schedule(classId = 1, subject = "Физика", teacher = "Петров И.П.", dayOfWeek = 1, lessonNumber = 2, classroom = "205"),
            Schedule(classId = 1, subject = "История", teacher = "Иванова М.И.", dayOfWeek = 1, lessonNumber = 3, classroom = "104"),
            Schedule(classId = 1, subject = "Математика", teacher = "Сидорова А.С.", dayOfWeek = 2, lessonNumber = 1, classroom = "301"),
            Schedule(classId = 1, subject = "Литература", teacher = "Козлов С.В.", dayOfWeek = 2, lessonNumber = 2, classroom = "208")
        )

        insertAll(sample)
    }

    // Получить всё расписание (если нужно)
    suspend fun getAllLessons(): List<Schedule> {
        // Получаем данные за ВСЕ ДНИ НЕДЕЛИ
        val result = mutableListOf<Schedule>()

        for (day in 1..7) {
            val lessons = scheduleDao.getScheduleByClassAndDay(1, day).first()
            result.addAll(lessons)
        }

        return result
    }
}

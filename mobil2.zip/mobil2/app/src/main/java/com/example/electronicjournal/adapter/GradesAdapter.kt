package com.example.electronicjournal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.electronicjournal.R
import com.example.electronicjournal.data.model.Grade

class GradesAdapter(
    private var gradesWithSubjects: List<Pair<Grade, String>>,
    private val userType: String = "student"
) : RecyclerView.Adapter<GradesAdapter.GradeViewHolder>() {

    var onSubjectClick: (String) -> Unit = {}

    class GradeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubject)
        val tvGrade: TextView = itemView.findViewById(R.id.tvGrade)
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GradeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_grade, parent, false)
        return GradeViewHolder(view)
    }

    override fun onBindViewHolder(holder: GradeViewHolder, position: Int) {
        val (grade, subjectName) = gradesWithSubjects[position]
        holder.tvSubject.text = subjectName
        holder.tvGrade.text = grade.grade.toString()
        holder.tvDate.text = grade.date

        holder.itemView.setOnClickListener {
            onSubjectClick(subjectName)
        }
    }

    override fun getItemCount(): Int = gradesWithSubjects.size

    fun updateData(data: List<Pair<Grade, String>>) {
        gradesWithSubjects = data
        notifyDataSetChanged()
    }
}

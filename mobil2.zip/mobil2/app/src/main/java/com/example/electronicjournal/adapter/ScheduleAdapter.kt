package com.example.electronicjournal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.electronicjournal.R
import com.example.electronicjournal.data.model.Schedule
import java.text.SimpleDateFormat
import java.util.*

class ScheduleAdapter(
    private var scheduleWithSubjects: List<Pair<Schedule, String>>,
    private val userType: String,
    private val onAttendanceClick: (Schedule) -> Unit = {},
    private val onAddGradeClick: (Schedule) -> Unit = {},
    private val onAddHomeworkClick: (Schedule) -> Unit = {}
) : RecyclerView.Adapter<ScheduleAdapter.ScheduleViewHolder>() {

    // Улучшение: текущий день недели и время
    private var currentDayOfWeek: Int = getCurrentDayOfWeek()
    private val currentTime: Calendar = Calendar.getInstance()

    // Улучшение: кэш для времени уроков
    private val lessonTimes = mapOf(
        1 to LessonTime("8:30", "9:15"),
        2 to LessonTime("9:25", "10:10"),
        3 to LessonTime("10:20", "11:05"),
        4 to LessonTime("11:20", "12:05"),
        5 to LessonTime("12:20", "13:05"),
        6 to LessonTime("13:15", "14:00"),
        7 to LessonTime("14:10", "14:55"),
        8 to LessonTime("15:05", "15:50")
    )

    data class LessonTime(val start: String, val end: String)

    class ScheduleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvLessonNumber: TextView = itemView.findViewById(R.id.tvLessonNumber)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubject)
        val tvTeacher: TextView = itemView.findViewById(R.id.tvTeacher)
        val tvRoom: TextView = itemView.findViewById(R.id.tvRoom)
        val llHomeworkInfo: View = itemView.findViewById(R.id.llHomeworkInfo)
        val tvHomework: TextView = itemView.findViewById(R.id.tvHomework)
        val tvHomeworkDue: TextView = itemView.findViewById(R.id.tvHomeworkDue)
        val llCurrentLesson: View = itemView.findViewById(R.id.llCurrentLesson)
        val tvTimeLeft: TextView = itemView.findViewById(R.id.tvTimeLeft)
        val llTeacherActions: View = itemView.findViewById(R.id.llTeacherActions)
        val btnAttendance: View = itemView.findViewById(R.id.btnAttendance)
        val btnAddGrade: View = itemView.findViewById(R.id.btnAddGrade)
        val btnAddHomework: View = itemView.findViewById(R.id.btnAddHomework)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScheduleViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_schedule, parent, false)
        return ScheduleViewHolder(view)
    }

    override fun onBindViewHolder(holder: ScheduleViewHolder, position: Int) {
        val (lesson, subjectName) = scheduleWithSubjects[position]

        // Обновляем текущее время перед отображением каждого элемента
        currentTime.timeInMillis = System.currentTimeMillis()

        holder.tvLessonNumber.text = "${lesson.lessonNumber} урок"
        holder.tvTime.text = getLessonTime(lesson.lessonNumber)
        holder.tvSubject.text = subjectName
        holder.tvTeacher.text = lesson.teacher
        holder.tvRoom.text = "каб. ${lesson.classroom}"

        setupHomeworkInfo(holder, lesson)
        setupCurrentLessonIndicator(holder, lesson)
        setupTeacherActions(holder, lesson)
        setupLessonStatus(holder, lesson)

        // Улучшение: разная подсветка в зависимости от статуса урока
        when {
            isCurrentLesson(lesson) -> {
                holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(holder.itemView.context, R.color.primary_light)
                )
            }
            isLessonPassed(lesson) -> {
                // Используем стандартный цвет вместо light_gray
                holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(holder.itemView.context, android.R.color.darker_gray)
                )
            }
            else -> {
                holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(holder.itemView.context, android.R.color.white)
                )
            }
        }
    }

    override fun getItemCount(): Int = scheduleWithSubjects.size

    fun updateData(newScheduleWithSubjects: List<Pair<Schedule, String>>) {
        scheduleWithSubjects = newScheduleWithSubjects
        notifyDataSetChanged()
    }

    // Улучшение: обновление текущего дня
    fun updateCurrentDay(dayOfWeek: Int) {
        currentDayOfWeek = dayOfWeek
        notifyDataSetChanged()
    }

    // УДАЛЕН неиспользуемый метод updateLesson
    // fun updateLesson(position: Int) {
    //     notifyItemChanged(position)
    // }

    private fun setupHomeworkInfo(holder: ScheduleViewHolder, lesson: Schedule) {
        // Улучшение: можно добавить реальные данные о домашнем задании
        val hasHomework = hasHomeworkForLesson(lesson)
        if (hasHomework) {
            holder.llHomeworkInfo.visibility = View.VISIBLE
            holder.tvHomework.text = "Д/З: ${getHomeworkForLesson(lesson)}"
            holder.tvHomeworkDue.text = "до ${getHomeworkDueDate(lesson)}"
        } else {
            holder.llHomeworkInfo.visibility = View.GONE
        }
    }

    private fun setupCurrentLessonIndicator(holder: ScheduleViewHolder, lesson: Schedule) {
        if (isCurrentLesson(lesson)) {
            holder.llCurrentLesson.visibility = View.VISIBLE
            holder.tvTimeLeft.text = calculateTimeLeft(lesson)
        } else {
            holder.llCurrentLesson.visibility = View.GONE
        }
    }

    private fun setupTeacherActions(holder: ScheduleViewHolder, lesson: Schedule) {
        if (userType == "teacher") {
            holder.llTeacherActions.visibility = View.VISIBLE
            holder.btnAttendance.setOnClickListener { onAttendanceClick(lesson) }
            holder.btnAddGrade.setOnClickListener { onAddGradeClick(lesson) }
            holder.btnAddHomework.setOnClickListener { onAddHomeworkClick(lesson) }

            // Улучшение: блокировка кнопок для прошедших уроков
            val isLessonPassed = isLessonPassed(lesson)
            holder.btnAttendance.isEnabled = !isLessonPassed
            holder.btnAddGrade.isEnabled = !isLessonPassed
            holder.btnAddHomework.isEnabled = !isLessonPassed

            // Визуальная индикация заблокированных кнопок
            val alpha = if (isLessonPassed) 0.5f else 1.0f
            holder.btnAttendance.alpha = alpha
            holder.btnAddGrade.alpha = alpha
            holder.btnAddHomework.alpha = alpha
        } else {
            holder.llTeacherActions.visibility = View.GONE
        }
    }

    // Новое улучшение: отображение статуса урока через существующие View
    private fun setupLessonStatus(holder: ScheduleViewHolder, lesson: Schedule) {
        // Используем tvTime для отображения статуса, если нужно
        val originalTime = getLessonTime(lesson.lessonNumber)
        val statusText = when {
            isCurrentLesson(lesson) -> {
                // Меняем цвет текста номера урока для текущего урока
                holder.tvLessonNumber.setTextColor(
                    ContextCompat.getColor(holder.itemView.context, R.color.purple_500)
                )
                "● $originalTime" // Добавляем индикатор текущего урока
            }
            isLessonPassed(lesson) -> {
                holder.tvLessonNumber.setTextColor(
                    ContextCompat.getColor(holder.itemView.context, android.R.color.darker_gray)
                )
                originalTime
            }
            else -> {
                holder.tvLessonNumber.setTextColor(
                    ContextCompat.getColor(holder.itemView.context, android.R.color.black)
                )
                originalTime
            }
        }
        holder.tvTime.text = statusText
    }

    private fun getLessonTime(lessonNumber: Int): String {
        val time = lessonTimes[lessonNumber]
        return if (time != null) "${time.start} - ${time.end}" else "--:-- - --:--"
    }

    // Улучшенная функция проверки текущего урока
    private fun isCurrentLesson(lesson: Schedule): Boolean {
        if (lesson.dayOfWeek != currentDayOfWeek) return false

        val currentLessonNumber = getCurrentLessonNumber()
        return lesson.lessonNumber == currentLessonNumber
    }

    // Улучшенная функция проверки прошедшего урока
    private fun isLessonPassed(lesson: Schedule): Boolean {
        if (lesson.dayOfWeek < currentDayOfWeek) return true
        if (lesson.dayOfWeek > currentDayOfWeek) return false

        // Если тот же день, проверяем по номеру урока
        val currentLessonNumber = getCurrentLessonNumber()
        return lesson.lessonNumber < currentLessonNumber
    }

    // Улучшенная функция расчета оставшегося времени
    private fun calculateTimeLeft(lesson: Schedule): String {
        val lessonTime = lessonTimes[lesson.lessonNumber] ?: return "---"

        try {
            val endTime = parseTime(lessonTime.end)
            val current = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, currentTime.get(Calendar.HOUR_OF_DAY))
                set(Calendar.MINUTE, currentTime.get(Calendar.MINUTE))
            }

            val diff = endTime.timeInMillis - current.timeInMillis
            if (diff <= 0) return "Завершен"

            val minutes = (diff / (1000 * 60)).toInt()
            return if (minutes < 60) {
                "${minutes} мин"
            } else {
                "${minutes / 60} ч ${minutes % 60} мин"
            }
        } catch (e: Exception) {
            return "---"
        }
    }

    // Вспомогательные функции для улучшений
    private fun getCurrentDayOfWeek(): Int {
        // В Java Calendar: 1-воскресенье, 2-понедельник...
        // Приводим к нашей системе: 1-понедельник, 7-воскресенье
        val calendarDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        return when (calendarDay) {
            Calendar.SUNDAY -> 7
            Calendar.MONDAY -> 1
            Calendar.TUESDAY -> 2
            Calendar.WEDNESDAY -> 3
            Calendar.THURSDAY -> 4
            Calendar.FRIDAY -> 5
            Calendar.SATURDAY -> 6
            else -> 1
        }
    }

    private fun getCurrentLessonNumber(): Int {
        val currentHour = currentTime.get(Calendar.HOUR_OF_DAY)
        val currentMinute = currentTime.get(Calendar.MINUTE)

        return when {
            currentHour < 8 || (currentHour == 8 && currentMinute < 30) -> 0 // До уроков
            currentHour < 9 || (currentHour == 9 && currentMinute < 15) -> 1
            currentHour < 10 || (currentHour == 10 && currentMinute < 10) -> 2
            currentHour < 11 || (currentHour == 11 && currentMinute < 5) -> 3
            currentHour < 12 || (currentHour == 12 && currentMinute < 5) -> 4
            currentHour < 13 || (currentHour == 13 && currentMinute < 5) -> 5
            currentHour < 14 || (currentHour == 14 && currentMinute < 0) -> 6
            currentHour < 15 || (currentHour == 15 && currentMinute < 50) -> 7
            else -> 8 // После уроков
        }
    }

    private fun parseTime(timeStr: String): Calendar {
        val format = SimpleDateFormat("HH:mm", Locale.getDefault())
        val date = format.parse(timeStr) ?: Date()
        return Calendar.getInstance().apply {
            time = date
        }
    }

    // Заглушки для будущей реализации
    private fun hasHomeworkForLesson(lesson: Schedule): Boolean {
        // Здесь можно добавить проверку в базе данных
        return lesson.lessonNumber % 2 == 0 // Пример: для четных уроков показываем ДЗ
    }

    private fun getHomeworkForLesson(lesson: Schedule): String {
        // Здесь можно получить домашнее задание из базы данных
        val subjects = mapOf(
            "Математика" to "Упражнения 1-5",
            "Физика" to "Лабораторная работа",
            "История" to "Подготовить доклад",
            "Литература" to "Прочитать главу"
        )
        return subjects[lesson.subject] ?: "Задание по предмету"
    }

    private fun getHomeworkDueDate(lesson: Schedule): String {
        // Здесь можно получить дату сдачи из базы данных
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, 7) // +7 дней от текущей даты
        val format = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        return format.format(calendar.time)
    }
}
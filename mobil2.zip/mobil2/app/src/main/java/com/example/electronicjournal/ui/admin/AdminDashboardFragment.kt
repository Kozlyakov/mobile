package com.example.electronicjournal.ui.admin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.electronicjournal.R
import com.example.electronicjournal.data.database.AppDatabase
import com.example.electronicjournal.data.model.Schedule
import com.example.electronicjournal.data.model.User
import com.example.electronicjournal.data.repository.ScheduleRepository
import com.example.electronicjournal.data.repository.UserRepository
import kotlinx.coroutines.launch

class AdminDashboardFragment : Fragment() {

    private lateinit var userRepo: UserRepository
    private lateinit var scheduleRepo: ScheduleRepository

    // UI элементы
    private lateinit var etLogin: EditText
    private lateinit var etPassword: EditText
    private lateinit var etFirstName: EditText
    private lateinit var etLastName: EditText
    private lateinit var spinnerRole: Spinner
    private lateinit var btnCreateUser: Button
    private lateinit var etDeleteUserId: EditText
    private lateinit var btnDeleteUser: Button

    private lateinit var etClassId: EditText
    private lateinit var etSubject: EditText
    private lateinit var etTeacher: EditText
    private lateinit var etDayOfWeek: EditText
    private lateinit var etLessonNumber: EditText
    private lateinit var etRoom: EditText
    private lateinit var btnCreateLesson: Button

    private lateinit var etDeleteLessonId: EditText
    private lateinit var btnDeleteLesson: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val db = AppDatabase.getInstance(requireContext())
        userRepo = UserRepository(db.userDao())
        scheduleRepo = ScheduleRepository(db.scheduleDao())

        // Инициализация View
        etLogin = view.findViewById(R.id.etLogin)
        etPassword = view.findViewById(R.id.etPassword)
        etFirstName = view.findViewById(R.id.etFirstName)
        etLastName = view.findViewById(R.id.etLastName)
        spinnerRole = view.findViewById(R.id.spinnerRole)
        btnCreateUser = view.findViewById(R.id.btnCreateUser)
        etDeleteUserId = view.findViewById(R.id.etDeleteUserId)
        btnDeleteUser = view.findViewById(R.id.btnDeleteUser)

        etClassId = view.findViewById(R.id.etClassId)
        etSubject = view.findViewById(R.id.etSubject)
        etTeacher = view.findViewById(R.id.etTeacher)
        etDayOfWeek = view.findViewById(R.id.etDayOfWeek)
        etLessonNumber = view.findViewById(R.id.etLessonNumber)
        etRoom = view.findViewById(R.id.etRoom)
        btnCreateLesson = view.findViewById(R.id.btnCreateLesson)

        etDeleteLessonId = view.findViewById(R.id.etDeleteLessonId)
        btnDeleteLesson = view.findViewById(R.id.btnDeleteLesson)

        setupRoleSpinner()
        setupUserActions()
        setupScheduleActions()
    }

    private fun setupRoleSpinner() {
        val roles = listOf("student", "teacher", "parent", "admin")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, roles)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRole.adapter = adapter
    }

    private fun setupUserActions() {

        btnCreateUser.setOnClickListener {
            val login = etLogin.text.toString()
            val password = etPassword.text.toString()
            val firstName = etFirstName.text.toString()
            val lastName = etLastName.text.toString()
            val userType = spinnerRole.selectedItem.toString()

            if (login.isEmpty() || password.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
                Toast.makeText(requireContext(), "Заполните все поля", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val user = User(
                login = login,
                password = password,
                firstName = firstName,
                lastName = lastName,
                userType = userType,
                className = if (userType == "student") "10A" else null
            )

            lifecycleScope.launch {
                try {
                    userRepo.addUser(user) // Исправлено на addUser
                    Toast.makeText(requireContext(), "Пользователь создан", Toast.LENGTH_SHORT).show()
                    clearUserFields()
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnDeleteUser.setOnClickListener {
            val login = etDeleteUserId.text.toString()
            if (login.isEmpty()) {
                Toast.makeText(requireContext(), "Введите логин пользователя", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                try {
                    userRepo.deleteUser(login) // Исправлено на deleteUser с логином
                    Toast.makeText(requireContext(), "Пользователь удалён", Toast.LENGTH_SHORT).show()
                    etDeleteUserId.text.clear()
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun setupScheduleActions() {

        btnCreateLesson.setOnClickListener {
            val classId = etClassId.text.toString().toIntOrNull()
            val subject = etSubject.text.toString()
            val teacher = etTeacher.text.toString()
            val dayOfWeek = etDayOfWeek.text.toString().toIntOrNull()
            val lessonNumber = etLessonNumber.text.toString().toIntOrNull()
            val classroom = etRoom.text.toString()

            if (classId == null || subject.isEmpty() || teacher.isEmpty() ||
                dayOfWeek == null || lessonNumber == null || classroom.isEmpty()) {
                Toast.makeText(requireContext(), "Заполните все поля корректно", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val lesson = Schedule(
                classId = classId,
                subject = subject,
                teacher = teacher,
                dayOfWeek = dayOfWeek,
                lessonNumber = lessonNumber,
                classroom = classroom
            )

            lifecycleScope.launch {
                try {
                    scheduleRepo.insertLesson(lesson) // Исправлено на insertLesson
                    Toast.makeText(requireContext(), "Урок добавлен", Toast.LENGTH_SHORT).show()
                    clearScheduleFields()
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnDeleteLesson.setOnClickListener {
            val lessonId = etDeleteLessonId.text.toString().toIntOrNull() ?: run {
                Toast.makeText(requireContext(), "Введите корректный ID урока", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                try {
                    scheduleRepo.deleteLesson(lessonId) // Исправлено на deleteLesson
                    Toast.makeText(requireContext(), "Урок удалён", Toast.LENGTH_SHORT).show()
                    etDeleteLessonId.text.clear()
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun clearUserFields() {
        etLogin.text.clear()
        etPassword.text.clear()
        etFirstName.text.clear()
        etLastName.text.clear()
    }

    private fun clearScheduleFields() {
        etClassId.text.clear()
        etSubject.text.clear()
        etTeacher.text.clear()
        etDayOfWeek.text.clear()
        etLessonNumber.text.clear()
        etRoom.text.clear()
    }
}
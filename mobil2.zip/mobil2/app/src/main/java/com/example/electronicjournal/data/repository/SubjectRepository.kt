package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.SubjectDao
import com.example.electronicjournal.data.model.Subject
import kotlinx.coroutines.flow.Flow

class SubjectRepository(private val subjectDao: SubjectDao) {

    fun getAllSubjects(): Flow<List<Subject>> {
        return subjectDao.getAllSubjects()
    }

    suspend fun initializeSampleData() {
        subjectDao.deleteAllSubjects()

        val sampleSubjects = listOf(
            Subject(name = "Математика", teacher = "Сидорова А.С."),
            Subject(name = "Физика", teacher = "Петров И.П."),
            Subject(name = "История", teacher = "Иванова М.И."),
            Subject(name = "Литература", teacher = "Козлов С.В.")
        )

        sampleSubjects.forEach { subjectDao.insertSubject(it) }
    }
}
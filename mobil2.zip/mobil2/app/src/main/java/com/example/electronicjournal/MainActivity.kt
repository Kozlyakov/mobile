package com.example.electronicjournal

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.example.electronicjournal.activity.LoginActivity
import com.example.electronicjournal.databinding.ActivityMainBinding
import com.example.electronicjournal.util.PreferenceHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var preferenceHelper: PreferenceHelper
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preferenceHelper = PreferenceHelper(this)
        setSupportActionBar(binding.toolbar)

        // Забираем данные пользователя из Intent (на всякий случай ещё раз сохраняем)
        readUserFromIntent()

        // Настраиваем навигацию и нижнее меню
        setupNavigation()
        adaptNavigationForUserType()

        // При первом запуске открываем нужный дашборд по роли
        if (savedInstanceState == null) {
            binding.bottomNavigation.selectedItemId = R.id.nav_dashboard
            navigateToDashboard()
        }
    }

    /**
     * Читаем данные из LoginActivity и кладём в PreferenceHelper
     */
    private fun readUserFromIntent() {
        val userId = intent.getIntExtra("USER_ID", 0)
        val userType = intent.getStringExtra("USER_TYPE") ?: preferenceHelper.getUserType()
        val userName = intent.getStringExtra("USER_NAME") ?: ""
        val className = intent.getStringExtra("CLASS_NAME") ?: ""

        if (userId != 0) {
            preferenceHelper.saveUserId(userId)
        }
        if (userType.isNotBlank()) {
            preferenceHelper.saveUserType(userType)
        }
        if (userName.isNotBlank()) {
            preferenceHelper.saveUserName(userName)
        }
        if (className.isNotBlank()) {
            preferenceHelper.saveClassName(className)
        }
    }

    /**
     * Настройка навигации и bottom navigation
     */
    private fun setupNavigation() {
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // ВАЖНО: НЕ привязываем setupWithNavController,
        // чтобы полностью контролировать переходы по ролям
        // binding.bottomNavigation.setupWithNavController(navController)

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            val role = preferenceHelper.getUserType()

            when (item.itemId) {
                R.id.nav_dashboard -> {
                    navigateToDashboard()
                    true
                }

                R.id.nav_grades -> {
                    when (role) {
                        PreferenceHelper.ROLE_TEACHER -> {
                            // Таблица оценок по классу
                            navigateSafe(R.id.studentGradesTableFragment)
                        }
                        PreferenceHelper.ROLE_STUDENT -> {
                            // Личные оценки студента
                            navigateSafe(R.id.gradesFragment)
                        }
                        PreferenceHelper.ROLE_PARENT -> {
                            // Оценки только ребёнка
                            navigateSafe(R.id.gradesFragment)
                        }
                        PreferenceHelper.ROLE_ADMIN -> {
                            Toast.makeText(
                                this,
                                "Оценки недоступны для администратора",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    true
                }

                R.id.nav_schedule -> {
                    when (role) {
                        PreferenceHelper.ROLE_TEACHER,
                        PreferenceHelper.ROLE_STUDENT,
                        PreferenceHelper.ROLE_PARENT -> {
                            // Общее расписание
                            navigateSafe(R.id.scheduleFragment)
                        }
                        PreferenceHelper.ROLE_ADMIN -> {
                            // У администратора расписание редактируется из его дашборда
                            navigateSafe(R.id.adminDashboardFragment)
                        }
                    }
                    true
                }

                R.id.nav_homework -> {
                    when (role) {
                        PreferenceHelper.ROLE_TEACHER -> {
                            // Список ДЗ + управление
                            navigateSafe(R.id.homeworkListFragment)
                        }
                        PreferenceHelper.ROLE_STUDENT,
                        PreferenceHelper.ROLE_PARENT -> {
                            // Домашка для конкретного ученика
                            navigateSafe(R.id.homeworkFragment)
                        }
                        PreferenceHelper.ROLE_ADMIN -> {
                            Toast.makeText(
                                this,
                                "Домашние задания недоступны для администратора",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    true
                }

                R.id.nav_profile -> {
                    // Профиль пользователя (ФИО, роль, класс, контакты)
                    navigateSafe(R.id.profileFragment)
                    true
                }

                else -> false
            }
        }
    }

    /**
     * Безопасная навигация: не переходим, если уже на этом экране
     */
    private fun navigateSafe(destinationId: Int) {
        val currentId = navController.currentDestination?.id
        if (currentId != destinationId) {
            try {
                navController.navigate(destinationId)
            } catch (e: IllegalArgumentException) {
                // Если вдруг destination ещё не в графе — покажем ошибку
                Toast.makeText(
                    this,
                    "Экран пока не подключен: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    /**
     * Куда отправлять пользователя при нажатии "Главная"
     * в зависимости от РОЛИ
     */
    private fun navigateToDashboard() {
        when {
            preferenceHelper.isTeacher() -> {
                navigateSafe(R.id.teacherDashboardFragment)
            }
            preferenceHelper.isStudent() -> {
                navigateSafe(R.id.studentDashboardFragment)
            }
            preferenceHelper.isParent() -> {
                navigateSafe(R.id.parentDashboardFragment)
            }
            preferenceHelper.isAdmin() -> {
                navigateSafe(R.id.adminDashboardFragment)
            }
            else -> {
                // на всякий случай
                navigateSafe(R.id.teacherDashboardFragment)
            }
        }
    }

    /**
     * Показываем/скрываем пункты нижнего меню в зависимости от роли
     */
    private fun adaptNavigationForUserType() {
        val menu = binding.bottomNavigation.menu
        when {
            preferenceHelper.isStudent() -> {
                // студенту нужны все разделы: оценки, расписание, ДЗ, профиль
                // оставляем всё как есть
            }
            preferenceHelper.isTeacher() -> {
                // преподаватель: оценки (класс), расписание, ДЗ, профиль
                // тоже ок, можно при желании спрятать профиль
                // menu.findItem(R.id.nav_profile)?.isVisible = false
            }
            preferenceHelper.isParent() -> {
                // родитель: оценки ребёнка, расписание, ДЗ, профиль
                // всё оставляем
            }
            preferenceHelper.isAdmin() -> {
                // админу — только главная (панель), расписание и профиль
                menu.findItem(R.id.nav_grades)?.isVisible = false
                menu.findItem(R.id.nav_homework)?.isVisible = false
            }
        }
    }

    // ==== Верхнее меню (три точки) ====

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                Toast.makeText(this, "Настройки в разработке", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_help -> {
                Toast.makeText(this, "Раздел помощи в разработке", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_logout -> {
                logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /**
     * Выход из аккаунта
     */
    private fun logout() {
        preferenceHelper.clearCredentials()
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
        Toast.makeText(this, "Вы вышли из системы", Toast.LENGTH_SHORT).show()
    }

    /**
     * Обработка системной кнопки "Назад":
     * - если уже на "Главная" — выходим
     * - иначе возвращаемся на "Главная"
     */
    override fun onBackPressed() {
        val selected = binding.bottomNavigation.selectedItemId

        if (selected == R.id.nav_dashboard) {
            finishAffinity()
        } else {
            binding.bottomNavigation.selectedItemId = R.id.nav_dashboard
            navigateToDashboard()
        }
    }
}

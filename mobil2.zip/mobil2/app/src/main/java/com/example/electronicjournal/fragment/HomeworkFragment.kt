package com.example.electronicjournal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.electronicjournal.adapter.HomeworkAdapter
import com.example.electronicjournal.databinding.FragmentHomeworkBinding

class HomeworkFragment : Fragment() {

    private var _binding: FragmentHomeworkBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: HomeworkAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentHomeworkBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = HomeworkAdapter(emptyList(), "student")
        binding.rvHomework.layoutManager = LinearLayoutManager(requireContext())
        binding.rvHomework.adapter = adapter

        binding.btnFilterSubject.setOnClickListener {
            Toast.makeText(requireContext(), "Фильтр по предметам (заглушка)", Toast.LENGTH_SHORT).show()
        }

        binding.btnFilterStatus.setOnClickListener {
            Toast.makeText(requireContext(), "Фильтр по статусу (заглушка)", Toast.LENGTH_SHORT).show()
        }

        binding.fabAddHomework.setOnClickListener {
            Toast.makeText(requireContext(), "Добавить ДЗ (заглушка)", Toast.LENGTH_SHORT).show()
        }

        binding.btnAddFirstHomework.setOnClickListener {
            Toast.makeText(requireContext(), "Добавить первое ДЗ (заглушка)", Toast.LENGTH_SHORT).show()
        }

        adapter.onHomeworkClick = { id ->
            Toast.makeText(requireContext(), "Открыть ДЗ №$id", Toast.LENGTH_SHORT).show()
        }
        adapter.onMarkDoneClick = { id ->
            Toast.makeText(requireContext(), "Отметить ДЗ №$id как выполненное (заглушка)", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

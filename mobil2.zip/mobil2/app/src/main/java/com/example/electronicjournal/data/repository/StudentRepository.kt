package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.database.StudentDao
import com.example.electronicjournal.data.model.Student
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class StudentRepository(
    private val studentDao: StudentDao
) {

    fun getStudentsByClass(className: String): Flow<List<Student>> {
        return studentDao.getStudentsByClass(className)
    }

    fun searchStudents(searchQuery: String): Flow<List<Student>> {
        return studentDao.searchStudents(searchQuery)
    }

    fun searchStudentsInClass(searchQuery: String, className: String): Flow<List<Student>> {
        return studentDao.searchStudentsInClass(searchQuery, className)
    }

    fun getActiveStudentsByClass(className: String): Flow<List<Student>> {
        return studentDao.getActiveStudentsByClass(className)
    }

    fun getAllClasses(): Flow<List<String>> {
        return studentDao.getAllClasses()
    }

    suspend fun getStudentById(studentId: Int): Student? {
        return studentDao.getStudentById(studentId)
    }

    suspend fun insertStudent(student: Student) {
        studentDao.insertStudent(student)
    }

    suspend fun insertAllStudents(students: List<Student>) {
        studentDao.insertAllStudents(students)
    }

    suspend fun updateStudent(student: Student) {
        studentDao.updateStudent(student)
    }

    suspend fun deleteStudent(student: Student) {
        studentDao.deleteStudent(student)
    }

    suspend fun deleteStudentById(studentId: Int) {
        studentDao.deleteStudentById(studentId)
    }

    suspend fun deleteStudentsByClass(className: String) {
        studentDao.deleteStudentsByClass(className)
    }

    suspend fun getStudentCountByClass(className: String): Int {
        return studentDao.getStudentCountByClass(className)
    }

    suspend fun getTotalStudentCount(): Int {
        return studentDao.getTotalStudentCount()
    }

    suspend fun updateStudentStatus(studentId: Int, isActive: Boolean) {
        studentDao.updateStudentStatus(studentId, isActive)
    }

    // Метод для получения всех классов в виде списка
    suspend fun getAllClassesList(): List<String> {
        return studentDao.getAllClasses().first()
    }

    // Метод для проверки существования ученика
    suspend fun studentExists(studentId: Int): Boolean {
        return studentDao.getStudentById(studentId) != null
    }
}

// Класс для объединенных данных ученика
data class StudentWithStats(
    val student: Student,
    val averageGrade: Double,
    val attendancePercentage: Double,
    val recentGrades: List<Int>
)
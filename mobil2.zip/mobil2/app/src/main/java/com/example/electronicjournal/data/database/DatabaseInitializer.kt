package com.example.electronicjournal.data.database

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import com.example.electronicjournal.data.model.Student
import com.example.electronicjournal.data.model.Attendance
import com.example.electronicjournal.data.model.Grade
import com.example.electronicjournal.data.model.Subject
import java.text.SimpleDateFormat
import java.util.*

class DatabaseInitializer(private val context: Context) {

    suspend fun initializeAllSampleData() {
        withContext(Dispatchers.IO) {
            val database = AppDatabase.getInstance(context)

            try {
                // Очистка старых данных
                database.studentDao().deleteStudentsByClass("10А")
                database.subjectDao().deleteAllSubjects()

                // Добавление предметов
                val subjects = listOf(
                    Subject(name = "Математика", teacher = "Иванова О.П."),
                    Subject(name = "Русский язык", teacher = "Петрова М.И."),
                    Subject(name = "Физика", teacher = "Сидоров А.В."),
                    Subject(name = "Химия", teacher = "Козлова Е.С."),
                    Subject(name = "История", teacher = "Николаев П.Д.")
                )
                database.subjectDao().insertAllSubjects(subjects)

                // Получаем ID добавленных предметов для использования в оценках и посещаемости
                val savedSubjects = database.subjectDao().getAllSubjects().first()

                // Добавление тестовых учеников
                val sampleStudents = listOf(
                    Student(1, "Иванов Алексей", "10А", "ivanov@school.ru", "+79991234567"),
                    Student(2, "Петрова Мария", "10А", "petrova@school.ru", "+79991234568"),
                    Student(3, "Сидоров Дмитрий", "10А", "sidorov@school.ru", "+79991234569"),
                    Student(4, "Козлова Анна", "10А", "kozlova@school.ru", "+79991234570"),
                    Student(5, "Николаев Иван", "10А", "nikolaev@school.ru", "+79991234571"),
                    Student(6, "Федорова Елена", "10А", "fedorova@school.ru", "+79991234572"),
                    Student(7, "Васильев Павел", "10А", "vasiliev@school.ru", "+79991234573"),
                    Student(8, "Алексеева Ольга", "10А", "alekseeva@school.ru", "+79991234574")
                )
                database.studentDao().insertAllStudents(sampleStudents)

                // Добавление оценок
                val grades = mutableListOf<Grade>()
                val random = Random()
                val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

                sampleStudents.forEach { student ->
                    savedSubjects.forEach { subject ->
                        // 2-4 оценки на ученика по предмету
                        repeat(random.nextInt(2, 5)) {
                            val gradeValue = random.nextInt(3, 6) // Оценки от 3 до 5
                            val gradeTypes = listOf("ответ", "дз", "тест", "контрольная")
                            grades.add(
                                Grade(
                                    studentId = student.id,
                                    subjectId = subject.id,
                                    grade = gradeValue,
                                    gradeType = gradeTypes[random.nextInt(gradeTypes.size)],
                                    date = dateFormat.format(Date()),
                                    comment = if (gradeValue == 5) "Отлично!" else null
                                )
                            )
                        }
                    }
                }
                database.gradeDao().insertAllGrades(grades)

                // Добавление посещаемости на сегодня
                val attendanceList = mutableListOf<Attendance>()
                val today = dateFormat.format(Date())

                sampleStudents.forEach { student ->
                    // 3 урока сегодня
                    repeat(3) { lessonNumber ->
                        val isPresent = random.nextFloat() > 0.2f // 80% присутствуют
                        attendanceList.add(
                            Attendance(
                                studentId = student.id,
                                subjectId = savedSubjects[lessonNumber % savedSubjects.size].id,
                                date = today,
                                lessonNumber = lessonNumber + 1,
                                isPresent = isPresent,
                                reason = if (!isPresent) when (random.nextInt(3)) {
                                    0 -> "болезнь"
                                    1 -> "семейные обстоятельства"
                                    else -> "прочее"
                                } else null
                            )
                        )
                    }
                }
                database.attendanceDao().insertAllAttendance(attendanceList)

                println("✅ База данных успешно инициализирована с тестовыми данными")

            } catch (e: Exception) {
                println("❌ Ошибка инициализации базы данных: ${e.message}")
                e.printStackTrace()
            }
        }
    }
}

// Extension function для Random
private fun Random.nextInt(from: Int, until: Int): Int {
    return nextInt(until - from) + from
}
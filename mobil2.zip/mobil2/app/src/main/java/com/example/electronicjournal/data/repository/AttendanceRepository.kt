package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.AttendanceDao
import com.example.electronicjournal.data.model.Attendance
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class AttendanceRepository(
    private val attendanceDao: AttendanceDao
) {

    fun getAttendanceByDateAndLesson(date: String, lessonNumber: Int): Flow<List<Attendance>> {
        return attendanceDao.getAttendanceByDateAndLesson(date, lessonNumber)
    }

    fun getStudentAttendanceByDate(studentId: Int, date: String): Flow<List<Attendance>> {
        return attendanceDao.getStudentAttendanceByDate(studentId, date)
    }

    fun getStudentAttendanceByPeriod(studentId: Int, startDate: String, endDate: String): Flow<List<Attendance>> {
        return attendanceDao.getStudentAttendanceByPeriod(studentId, startDate, endDate)
    }

    suspend fun insertAttendance(attendance: Attendance) {
        attendanceDao.insertAttendance(attendance)
    }

    suspend fun insertAllAttendance(attendanceList: List<Attendance>) {
        attendanceDao.insertAllAttendance(attendanceList)
    }

    suspend fun updateAttendance(attendance: Attendance) {
        attendanceDao.updateAttendance(attendance)
    }

    suspend fun deleteAttendance(attendanceId: Int) {
        attendanceDao.deleteAttendance(attendanceId)
    }

    // Метод для отметки посещаемости на текущий день
    suspend fun markAttendanceForToday(studentIds: List<Int>, subjectId: Int, lessonNumber: Int, isPresent: Boolean) {
        val date = getCurrentDate()
        val attendanceList = studentIds.map { studentId ->
            Attendance(
                studentId = studentId,
                subjectId = subjectId,
                date = date,
                lessonNumber = lessonNumber,
                isPresent = isPresent
            )
        }
        attendanceDao.insertAllAttendance(attendanceList)
    }

    // Метод для получения статистики посещаемости
    suspend fun getAttendanceStats(studentId: Int, startDate: String, endDate: String): AttendanceStats {
        val presentDays = attendanceDao.getPresentDaysCount(studentId, startDate, endDate)
        val totalDays = attendanceDao.getTotalDaysCount(studentId, startDate, endDate)
        val percentage = if (totalDays > 0) (presentDays.toDouble() / totalDays * 100) else 0.0

        return AttendanceStats(
            presentDays = presentDays,
            absentDays = totalDays - presentDays,
            totalDays = totalDays,
            percentage = percentage
        )
    }

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return dateFormat.format(Date())
    }
}

// Статистика посещаемости
data class AttendanceStats(
    val presentDays: Int,
    val absentDays: Int,
    val totalDays: Int,
    val percentage: Double
)
package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.Homework
import kotlinx.coroutines.flow.Flow

@Dao
interface HomeworkDao {

    @Query("SELECT * FROM homework WHERE classId = :classId AND dueDate >= date('now') ORDER BY dueDate")
    fun getHomeworkByClass(classId: Int): Flow<List<Homework>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHomework(homework: Homework)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllHomework(homeworkList: List<Homework>)

    @Query("DELETE FROM homework")
    suspend fun deleteAllHomework()
}
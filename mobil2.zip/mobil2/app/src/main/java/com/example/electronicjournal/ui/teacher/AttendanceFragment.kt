package com.example.electronicjournal.ui.teacher

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.electronicjournal.data.model.Student
import com.example.electronicjournal.databinding.FragmentAttendanceBinding
import com.example.electronicjournal.ui.teacher.adapters.AttendanceAdapter

class AttendanceFragment : Fragment() {

    private var _binding: FragmentAttendanceBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: AttendanceAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAttendanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupClickListeners()
        loadStudents()
        updateStats()
    }

    private fun setupRecyclerView() {
        adapter = AttendanceAdapter { _, _ ->
            // Обновляем статистику при изменении посещаемости
            updateStats()
        }

        binding.rvStudents.layoutManager = LinearLayoutManager(requireContext())
        binding.rvStudents.adapter = adapter
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.btnMarkAllPresent.setOnClickListener {
            adapter.markAllPresent()
            updateStats()
        }

        binding.btnMarkAllAbsent.setOnClickListener {
            adapter.markAllAbsent()
            updateStats()
        }

        binding.btnSaveAttendance.setOnClickListener {
            saveAttendance()
        }
    }

    private fun loadStudents() {
        // Временные данные
        val students = listOf(
            Student(1, "Иванов Алексей", "10А", ""),
            Student(2, "Петрова Мария", "10А", ""),
            Student(3, "Сидоров Дмитрий", "10А", ""),
            Student(4, "Козлова Анна", "10А", ""),
            Student(5, "Николаев Иван", "10А", ""),
            Student(6, "Смирнова Ольга", "10А", ""),
            Student(7, "Васильев Петр", "10А", ""),
            Student(8, "Федорова Елена", "10А", "")
        )
        adapter.submitList(students)
    }

    private fun updateStats() {
        val attendance = adapter.getAttendanceStats()
        binding.tvPresentCount.text = attendance.present.toString()
        binding.tvAbsentCount.text = attendance.absent.toString()
        binding.tvTotalCount.text = attendance.total.toString()
    }

    private fun saveAttendance() {
        val attendance = adapter.getAttendance()
        if (attendance.isNotEmpty()) {
            android.widget.Toast.makeText(
                requireContext(),
                "Посещаемость сохранена\nПрисутствуют: ${adapter.getAttendanceStats().present}",
                android.widget.Toast.LENGTH_LONG
            ).show()
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.Grade
import kotlinx.coroutines.flow.Flow

@Dao
interface GradeDao {

    @Query("SELECT * FROM grades WHERE studentId = :studentId ORDER BY date DESC")
    fun getGradesByStudent(studentId: Int): Flow<List<Grade>>

    @Query("SELECT * FROM grades WHERE studentId = :studentId AND subjectId = :subjectId")
    fun getGradesByStudentAndSubject(studentId: Int, subjectId: Int): Flow<List<Grade>>

    @Query("SELECT * FROM grades WHERE subjectId = :subjectId ORDER BY date DESC")
    fun getGradesBySubject(subjectId: Int): Flow<List<Grade>>

    @Query("SELECT * FROM grades WHERE date = :date")
    fun getGradesByDate(date: String): Flow<List<Grade>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrade(grade: Grade)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllGrades(grades: List<Grade>)

    @Update
    suspend fun updateGrade(grade: Grade)

    @Query("DELETE FROM grades WHERE id = :gradeId")
    suspend fun deleteGrade(gradeId: Int)

    @Query("DELETE FROM grades WHERE studentId = :studentId")
    suspend fun deleteGradesByStudent(studentId: Int)

    @Query("DELETE FROM grades WHERE subjectId = :subjectId")
    suspend fun deleteGradesBySubject(subjectId: Int)

    @Query("DELETE FROM grades")
    suspend fun deleteAllGrades()

    // Метод для получения средней оценки по предмету
    @Query("SELECT AVG(grade) FROM grades WHERE studentId = :studentId AND subjectId = :subjectId")
    suspend fun getAverageGrade(studentId: Int, subjectId: Int): Double?

    // Метод для получения оценок по классу
    @Query("SELECT * FROM grades WHERE studentId IN (SELECT id FROM students WHERE className = :className)")
    fun getGradesByClass(className: String): Flow<List<Grade>>

    // Метод для получения последних оценок
    @Query("SELECT * FROM grades WHERE studentId = :studentId ORDER BY date DESC LIMIT :limit")
    fun getRecentGrades(studentId: Int, limit: Int): Flow<List<Grade>>
}
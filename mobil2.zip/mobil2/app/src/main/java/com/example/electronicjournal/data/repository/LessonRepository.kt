package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.LessonDao
import com.example.electronicjournal.data.model.Lesson
import kotlinx.coroutines.flow.Flow

class LessonRepository(
    private val lessonDao: LessonDao
) {

    fun getLessonsByClassAndDay(className: String, dayOfWeek: Int): Flow<List<Lesson>> {
        return lessonDao.getLessonsByClassAndDay(className, dayOfWeek)
    }

    fun getLessonsByClass(className: String): Flow<List<Lesson>> {
        return lessonDao.getLessonsByClass(className)
    }

    fun getTeacherLessonsByDay(teacherId: Int, dayOfWeek: Int): Flow<List<Lesson>> {
        return lessonDao.getTeacherLessonsByDay(teacherId, dayOfWeek)
    }

    suspend fun insertLesson(lesson: Lesson) {
        lessonDao.insertLesson(lesson)
    }

    suspend fun insertAllLessons(lessons: List<Lesson>) {
        lessonDao.insertAllLessons(lessons)
    }

    suspend fun updateLesson(lesson: Lesson) {
        lessonDao.updateLesson(lesson)
    }

    suspend fun deleteLesson(lessonId: Int) {
        lessonDao.deleteLesson(lessonId)
    }

    // Метод для инициализации тестового расписания
    suspend fun initializeSampleLessons() {
        lessonDao.deleteLessonsByClass("10А")

        val sampleLessons = listOf(
            Lesson(subjectId = 1, className = "10А", dayOfWeek = 1, lessonNumber = 1, classroom = "101", teacherId = 1),
            Lesson(subjectId = 2, className = "10А", dayOfWeek = 1, lessonNumber = 2, classroom = "102", teacherId = 2),
            Lesson(subjectId = 1, className = "10А", dayOfWeek = 2, lessonNumber = 1, classroom = "101", teacherId = 1),
            Lesson(subjectId = 3, className = "10А", dayOfWeek = 2, lessonNumber = 2, classroom = "103", teacherId = 3),
            Lesson(subjectId = 2, className = "10А", dayOfWeek = 3, lessonNumber = 1, classroom = "102", teacherId = 2),
            Lesson(subjectId = 1, className = "10А", dayOfWeek = 4, lessonNumber = 1, classroom = "101", teacherId = 1),
            Lesson(subjectId = 3, className = "10А", dayOfWeek = 5, lessonNumber = 1, classroom = "103", teacherId = 3)
        )

        lessonDao.insertAllLessons(sampleLessons)
    }
}
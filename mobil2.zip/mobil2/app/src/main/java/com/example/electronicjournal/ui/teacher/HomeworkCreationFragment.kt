package com.example.electronicjournal.ui.teacher

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.electronicjournal.databinding.FragmentHomeworkCreationBinding
import java.text.SimpleDateFormat
import java.util.*

class HomeworkCreationFragment : Fragment() {

    private var _binding: FragmentHomeworkCreationBinding? = null
    private val binding get() = _binding!!
    private val calendar = Calendar.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeworkCreationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupClickListeners()
        setupSpinners()
        setDefaultDate()
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }

        binding.etDueDate.setOnClickListener {
            showDatePicker()
        }

        binding.btnSaveHomework.setOnClickListener {
            saveHomework()
        }
    }

    private fun setupSpinners() {
        // Временные данные - замени на реальные из базы
        // Переменные subjects и classes больше не объявляются, т.к. не используются
        // Здесь нужно будет настроить адаптеры для spinner
        // Пока просто установим заглушки
        binding.tvSubject.text = "Математика"
        binding.tvClass.text = "10А"
    }

    private fun setDefaultDate() {
        // Устанавливаем дату на завтра по умолчанию
        calendar.add(Calendar.DAY_OF_MONTH, 1)
        updateDateText()
    }

    private fun showDatePicker() {
        val datePicker = DatePickerDialog(
            requireContext(),
            { _, year, month, day ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, day)
                updateDateText()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        // Запрещаем выбор прошедших дат
        datePicker.datePicker.minDate = System.currentTimeMillis() - 1000
        datePicker.show()
    }

    private fun updateDateText() {
        val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        binding.etDueDate.setText(dateFormat.format(calendar.time))
    }

    private fun saveHomework() {
        val subject = binding.tvSubject.text.toString()
        val className = binding.tvClass.text.toString()
        val description = binding.etDescription.text.toString()
        val dueDate = binding.etDueDate.text.toString()

        if (description.isBlank() || dueDate.isBlank()) {
            android.widget.Toast.makeText(
                requireContext(),
                "Заполните все поля",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Здесь будет сохранение в базу данных
        android.widget.Toast.makeText(
            requireContext(),
            "ДЗ по $subject для $className сохранено\nСрок: $dueDate",
            android.widget.Toast.LENGTH_LONG
        ).show()

        requireActivity().onBackPressedDispatcher.onBackPressed()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.GradeDao
import com.example.electronicjournal.data.model.Grade
import kotlinx.coroutines.flow.Flow

class GradeRepository(private val gradeDao: GradeDao) {

    fun getGradesByStudent(studentId: Int): Flow<List<Grade>> {
        return gradeDao.getGradesByStudent(studentId)
    }

    fun getGradesByStudentAndSubject(studentId: Int, subjectId: Int): Flow<List<Grade>> {
        return gradeDao.getGradesByStudentAndSubject(studentId, subjectId)
    }

    suspend fun addGrade(grade: Grade) {
        gradeDao.insertGrade(grade)
    }

    suspend fun initializeSampleGrades() {
        gradeDao.deleteAllGrades()

        val sampleGrades = listOf(
            Grade(studentId = 1, subjectId = 1, grade = 5, gradeType = "ответ", date = "2024-01-15", comment = "Отлично!"),
            Grade(studentId = 1, subjectId = 2, grade = 4, gradeType = "тест", date = "2024-01-14"),
            Grade(studentId = 1, subjectId = 1, grade = 3, gradeType = "дз", date = "2024-01-13"),
            Grade(studentId = 2, subjectId = 1, grade = 5, gradeType = "ответ", date = "2024-01-15"),
            Grade(studentId = 2, subjectId = 2, grade = 5, gradeType = "тест", date = "2024-01-14")
        )

        gradeDao.insertAllGrades(sampleGrades)
    }
}
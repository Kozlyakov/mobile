package com.example.electronicjournal.ui.teacher

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.core.view.MenuHost
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.electronicjournal.R
import com.example.electronicjournal.data.database.AppDatabase
import com.example.electronicjournal.data.model.Student
import com.example.electronicjournal.data.repository.StudentRepository
import com.example.electronicjournal.databinding.FragmentStudentGradesTableBinding
import com.example.electronicjournal.ui.teacher.adapters.StudentGradesTableAdapter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class StudentGradesTableFragment : Fragment() {

    private var _binding: FragmentStudentGradesTableBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: StudentGradesTableAdapter
    private lateinit var studentRepository: StudentRepository
    private lateinit var database: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStudentGradesTableBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = AppDatabase.getInstance(requireContext())
        studentRepository = StudentRepository(database.studentDao())

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        setupMenu()
        initializeAndLoadData()
    }

    override fun onResume() {
        super.onResume()
        // Обновляем данные при возврате на фрагмент
        refreshData()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupMenu() {
        val menuHost: MenuHost = requireActivity()
        menuHost.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.menu_student_grades, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId) {
                    R.id.action_refresh -> {
                        refreshData()
                        true
                    }
                    R.id.action_settings -> {
                        showTableSettings()
                        true
                    }
                    else -> false
                }
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    private fun setupRecyclerView() {
        adapter = StudentGradesTableAdapter()
        binding.rvStudentsTable.layoutManager = LinearLayoutManager(requireContext())
        binding.rvStudentsTable.adapter = adapter

        // Обработчики кликов
        adapter.onGradeClick = { student, _ ->
            showGradeDialog(student)
        }

        adapter.onAttendanceClick = { student, _ ->
            showAttendanceDialog(student)
        }
    }

    private fun setupClickListeners() {
        binding.btnExport.setOnClickListener {
            exportData()
        }

        binding.btnFilter.setOnClickListener {
            showFilterDialog()
        }

        // ДОБАВЛЕНА КНОПКА БЫСТРОГО ВЫСТАВЛЕНИЯ
        binding.btnQuickGradeAssignment.setOnClickListener {
            navigateToGradeAssignment()
        }
    }

    private fun navigateToGradeAssignment() {
        // Упрощенная навигация - используем ID напрямую
        try {
            findNavController().navigate(R.id.gradeAssignmentFragment)
        } catch (e: Exception) {
            showToast("Ошибка навигации: ${e.message}")
        }
    }

    private fun initializeAndLoadData() {
        lifecycleScope.launch {
            try {
                binding.tvSubtitle.text = "Загрузка данных..."
                loadRealData()
            } catch (e: Exception) {
                showToast("Ошибка загрузки данных: ${e.message}")
                loadDemoData()
            }
        }
    }

    private fun loadRealData() {
        lifecycleScope.launch {
            try {
                // Загрузка реальных учеников из базы
                val students = studentRepository.getStudentsByClass("10А").first()

                if (students.isEmpty()) {
                    loadDemoData()
                    return@launch
                }

                // ЗАГРУЖАЕМ РЕАЛЬНЫЕ ДАННЫЕ ИЗ БАЗЫ
                val grades = mutableMapOf<Int, List<Int>>()
                val attendance = mutableMapOf<Int, Boolean>()

                students.forEach { student ->
                    // Загружаем реальные оценки студента из базы
                    val studentGrades = database.gradeDao().getGradesByStudent(student.id).first()
                    grades[student.id] = studentGrades.map { it.grade }

                    // Загружаем сегодняшнюю посещаемость из базы
                    val today = getCurrentDate()
                    // Используем существующий метод из AttendanceDao
                    val todayAttendance = database.attendanceDao()
                        .getStudentAttendanceByDate(student.id, today).first()
                    attendance[student.id] = todayAttendance.firstOrNull()?.isPresent ?: true
                }

                adapter.updateData(students, grades, attendance)

                binding.tvTitle.text = "Оценки и посещаемость - 10А"
                binding.tvSubtitle.text = "${students.size} учеников • ${getCurrentDate()}"

            } catch (e: Exception) {
                showToast("Ошибка загрузки: ${e.message}")
                loadDemoData()
            }
        }
    }

    private fun loadDemoData() {
        // Демо-данные на случай ошибки загрузки из базы
        val sampleStudents = listOf(
            Student(1, "Иванов Алексей", "10А", "ivanov@school.ru"),
            Student(2, "Петрова Мария", "10А", "petrova@school.ru"),
            Student(3, "Сидоров Дмитрий", "10А", "sidorov@school.ru"),
            Student(4, "Козлова Анна", "10А", "kozlova@school.ru"),
            Student(5, "Николаев Иван", "10А", "nikolaev@school.ru")
        )

        val grades = mapOf(
            1 to listOf(5, 4, 5, 4),
            2 to listOf(5, 5, 4, 5),
            3 to listOf(3, 4, 3, 4),
            4 to listOf(4, 4, 5, 4),
            5 to listOf(5, 3, 4, 5)
        )

        val attendance = mapOf(
            1 to true, 2 to true, 3 to false, 4 to true, 5 to true
        )

        adapter.updateData(sampleStudents, grades, attendance)
        binding.tvTitle.text = "Оценки и посещаемость - 10А (демо)"
        binding.tvSubtitle.text = "${sampleStudents.size} учеников • Демо-данные"
    }

    private fun getCurrentDate(): String {
        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        return dateFormat.format(java.util.Date())
    }

    private fun refreshData() {
        showToast("Обновление данных...")
        loadRealData()
    }

    private fun showTableSettings() {
        val options = arrayOf("Показать только оценки", "Показать только посещаемость", "Показать всё")

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Настройки отображения")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showToast("Режим: только оценки")
                    1 -> showToast("Режим: только посещаемость")
                    2 -> showToast("Режим: все данные")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun exportData() {
        lifecycleScope.launch {
            try {
                val students = studentRepository.getStudentsByClass("10А").first()
                showToast("Экспортировано данных: ${students.size} учеников")
            } catch (e: Exception) {
                showToast("Ошибка экспорта: ${e.message}")
            }
        }
    }

    private fun showFilterDialog() {
        val filterOptions = arrayOf("Все ученики", "Только с оценками", "Только отсутствующие", "Только отличники")

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Фильтр данных")
            .setItems(filterOptions) { _, which ->
                when (which) {
                    0 -> showToast("Показаны все ученики")
                    1 -> showToast("Показаны только ученики с оценками")
                    2 -> showToast("Показаны только отсутствующие")
                    3 -> showToast("Показаны только отличники")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showGradeDialog(student: Student) {
        val grades = arrayOf("2", "3", "4", "5", "Быстрое выставление", "н/а")

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Оценка для ${student.name}")
            .setItems(grades) { _, which ->
                when (which) {
                    4 -> {
                        // Переход к быстрому выставлению оценок
                        navigateToGradeAssignment()
                    }
                    5 -> {
                        // н/а - ничего не делать
                    }
                    else -> {
                        val selectedGrade = grades[which]
                        if (selectedGrade != "н/а") {
                            lifecycleScope.launch {
                                try {
                                    val newGrade = com.example.electronicjournal.data.model.Grade(
                                        studentId = student.id,
                                        subjectId = 1,
                                        grade = selectedGrade.toInt(),
                                        gradeType = "ответ",
                                        date = getCurrentDate(),
                                        comment = "Выставлено учителем"
                                    )
                                    database.gradeDao().insertGrade(newGrade)
                                    adapter.updateGrade(student.id, selectedGrade.toInt())
                                    showToast("Оценка $selectedGrade выставлена для ${student.name}")
                                } catch (e: Exception) {
                                    showToast("Ошибка сохранения оценки: ${e.message}")
                                }
                            }
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showAttendanceDialog(student: Student) {
        val options = arrayOf("Присутствует ✓", "Отсутствует ✗")

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Посещаемость ${student.name}")
            .setItems(options) { _, which ->
                val newAttendance = which == 0
                lifecycleScope.launch {
                    try {
                        val newAttendanceRecord = com.example.electronicjournal.data.model.Attendance(
                            studentId = student.id,
                            subjectId = 1,
                            date = getCurrentDate(),
                            lessonNumber = 1,
                            isPresent = newAttendance,
                            reason = if (!newAttendance) "отметка учителя" else null
                        )
                        database.attendanceDao().insertAttendance(newAttendanceRecord)
                        adapter.updateAttendance(student.id, newAttendance)
                        val status = if (newAttendance) "присутствует" else "отсутствует"
                        showToast("${student.name} отмечен как $status")
                    } catch (e: Exception) {
                        showToast("Ошибка сохранения посещаемости: ${e.message}")
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showToast(message: String) {
        android.widget.Toast.makeText(requireContext(), message, android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
package com.example.electronicjournal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.electronicjournal.adapter.SchedulePagerAdapter
import com.example.electronicjournal.databinding.FragmentScheduleBinding
import com.google.android.material.tabs.TabLayoutMediator
import java.util.*

class ScheduleFragment : Fragment() {

    private var _binding: FragmentScheduleBinding? = null
    private val binding get() = _binding!!

    private val dayTitles = listOf("ПН","ВТ","СР","ЧТ","ПТ","СБ")
    private lateinit var pagerAdapter: SchedulePagerAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentScheduleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        pagerAdapter = SchedulePagerAdapter(requireActivity(), dayTitles.size)
        binding.pagerDays.adapter = pagerAdapter

        TabLayoutMediator(binding.tabDays, binding.pagerDays) { tab, position ->
            tab.text = dayTitles[position]
        }.attach()

        val cal = Calendar.getInstance()
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        val index = when (dow) {
            Calendar.MONDAY -> 0
            Calendar.TUESDAY -> 1
            Calendar.WEDNESDAY -> 2
            Calendar.THURSDAY -> 3
            Calendar.FRIDAY -> 4
            Calendar.SATURDAY -> 5
            else -> 0
        }
        binding.pagerDays.post { binding.pagerDays.setCurrentItem(index, false) }

        binding.fabWeekSwitch.setOnClickListener {
            Toast.makeText(requireContext(), "Смена недели (заглушка)", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

package com.example.electronicjournal.ui.teacher

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.electronicjournal.data.database.AppDatabase
import com.example.electronicjournal.data.repository.ScheduleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class TeacherViewModel(private val database: AppDatabase) : ViewModel() {

    private val scheduleRepository = ScheduleRepository(database.scheduleDao())

    // Статистика преподавателя
    private val _averageGrade = MutableStateFlow(4.2f)
    val averageGrade: StateFlow<Float> = _averageGrade

    private val _totalGrades = MutableStateFlow(156)
    val totalGrades: StateFlow<Int> = _totalGrades

    private val _totalLessons = MutableStateFlow(32)
    val totalLessons: StateFlow<Int> = _totalLessons

    // Расписание
    private val _todaySchedule = MutableStateFlow<List<String>>(emptyList())
    val todaySchedule: StateFlow<List<String>> = _todaySchedule

    init {
        loadTeacherStatistics()
        loadTodaySchedule()
    }

    private fun loadTeacherStatistics() {
        // Здесь будет логика загрузки реальных данных
        // Пока используем mock данные
        _averageGrade.value = 4.2f
        _totalGrades.value = 156
        _totalLessons.value = 32
    }

    private fun loadTodaySchedule() {
        viewModelScope.launch {
            try {
                val currentDayOfWeek = getCurrentDayOfWeek()
                scheduleRepository.getScheduleByClassAndDay(1, currentDayOfWeek).collect { lessons ->
                    val scheduleTexts = lessons.map { lesson ->
                        "${getLessonTime(lesson.lessonNumber)} - ${lesson.subject} (${lesson.classroom})"
                    }
                    _todaySchedule.value = scheduleTexts
                }
            } catch (e: Exception) {
                _todaySchedule.value = listOf("Ошибка загрузки расписания")
            }
        }
    }

    private fun getCurrentDayOfWeek(): Int {
        val calendarDay = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK)
        return when (calendarDay) {
            java.util.Calendar.MONDAY -> 1
            java.util.Calendar.TUESDAY -> 2
            java.util.Calendar.WEDNESDAY -> 3
            java.util.Calendar.THURSDAY -> 4
            java.util.Calendar.FRIDAY -> 5
            java.util.Calendar.SATURDAY -> 6
            java.util.Calendar.SUNDAY -> 7
            else -> 1
        }
    }

    private fun getLessonTime(lessonNumber: Int): String {
        val lessonTimes = mapOf(
            1 to "8:30-9:15", 2 to "9:25-10:10", 3 to "10:20-11:05",
            4 to "11:20-12:05", 5 to "12:20-13:05", 6 to "13:15-14:00",
            7 to "14:10-14:55", 8 to "15:05-15:50"
        )
        return lessonTimes[lessonNumber] ?: ""
    }
}
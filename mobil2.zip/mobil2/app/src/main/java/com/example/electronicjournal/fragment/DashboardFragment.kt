package com.example.electronicjournal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.electronicjournal.R
import com.example.electronicjournal.databinding.FragmentDashboardBinding

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        // Кнопки на дашборде ведут в соответствующие разделы
        binding.tvRecentGrades.setOnClickListener {
            // Навигация к фрагменту оценок
            // Если есть отдельный граф навигации для оценок, используйте navigate
            // findNavController().navigate(R.id.action_to_grades)
            showToast("Переход к оценкам")
        }

        binding.tvPendingHomework.setOnClickListener {
            // Навигация к фрагменту домашних заданий
            // findNavController().navigate(R.id.action_to_homework)
            showToast("Переход к домашним заданиям")
        }

        binding.tvTodayLessons.setOnClickListener {
            // Навигация к фрагменту расписания
            // findNavController().navigate(R.id.action_to_schedule)
            showToast("Переход к расписанию")
        }
    }

    private fun showToast(message: String) {
        android.widget.Toast.makeText(requireContext(), message, android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
package com.example.electronicjournal.ui.teacher.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.electronicjournal.data.model.Student
import com.example.electronicjournal.databinding.ItemAttendanceBinding

data class AttendanceStats(
    val present: Int,
    val absent: Int,
    val total: Int
)

class AttendanceAdapter(
    private val onAttendanceChange: (Student, Boolean) -> Unit
) : ListAdapter<Student, AttendanceAdapter.AttendanceViewHolder>(DiffCallback) {

    private val attendance = mutableMapOf<Int, Boolean>()

    inner class AttendanceViewHolder(private val binding: ItemAttendanceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(student: Student) {
            binding.tvStudentName.text = student.name
            binding.tvStudentClass.text = student.className

            val isPresent = attendance[student.id] ?: true
            updateAppearance(isPresent)

            binding.switchAttendance.isChecked = isPresent

            binding.switchAttendance.setOnCheckedChangeListener { _, isChecked ->
                attendance[student.id] = isChecked
                updateAppearance(isChecked)
                onAttendanceChange(student, isChecked)
            }

            binding.root.setOnClickListener {
                val newState = !(attendance[student.id] ?: true)
                binding.switchAttendance.isChecked = newState
            }
        }

        private fun updateAppearance(isPresent: Boolean) {
            if (isPresent) {
                binding.tvStatus.text = "Присутствует"
                binding.tvStatus.setTextColor(binding.root.context.getColor(android.R.color.holo_green_dark))
            } else {
                binding.tvStatus.text = "Отсутствует"
                binding.tvStatus.setTextColor(binding.root.context.getColor(android.R.color.holo_red_dark))
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AttendanceViewHolder {
        val binding = ItemAttendanceBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AttendanceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AttendanceViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun markAllPresent() {
        currentList.forEach { student ->
            attendance[student.id] = true
        }
        notifyDataSetChanged()
    }

    fun markAllAbsent() {
        currentList.forEach { student ->
            attendance[student.id] = false
        }
        notifyDataSetChanged()
    }

    fun getAttendance(): Map<Int, Boolean> {
        return attendance.toMap()
    }

    fun getAttendanceStats(): AttendanceStats {
        val presentCount = attendance.values.count { it }
        val totalCount = currentList.size
        return AttendanceStats(
            present = presentCount,
            absent = totalCount - presentCount,
            total = totalCount
        )
    }

    companion object DiffCallback : DiffUtil.ItemCallback<Student>() {
        override fun areItemsTheSame(oldItem: Student, newItem: Student): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Student, newItem: Student): Boolean {
            return oldItem == newItem
        }
    }
}
package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.Attendance
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {

    @Query("SELECT * FROM attendance WHERE date = :date AND lessonNumber = :lessonNumber")
    fun getAttendanceByDateAndLesson(date: String, lessonNumber: Int): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE studentId = :studentId AND date = :date")
    fun getStudentAttendanceByDate(studentId: Int, date: String): Flow<List<Attendance>>

    // ДОБАВЛЕН НОВЫЙ МЕТОД - исправление ошибки
    @Query("SELECT * FROM attendance WHERE studentId = :studentId AND date = :date")
    fun getAttendanceByStudentAndDate(studentId: Int, date: String): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE studentId = :studentId AND date BETWEEN :startDate AND :endDate")
    fun getStudentAttendanceByPeriod(studentId: Int, startDate: String, endDate: String): Flow<List<Attendance>>

    @Query("SELECT * FROM attendance WHERE studentId = :studentId")
    fun getAttendanceByStudent(studentId: Int): Flow<List<Attendance>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: Attendance)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAttendance(attendanceList: List<Attendance>)

    @Update
    suspend fun updateAttendance(attendance: Attendance)

    @Query("DELETE FROM attendance WHERE id = :attendanceId")
    suspend fun deleteAttendance(attendanceId: Int)

    @Query("DELETE FROM attendance WHERE date BETWEEN :startDate AND :endDate")
    suspend fun deleteAttendanceByPeriod(startDate: String, endDate: String)

    @Query("DELETE FROM attendance WHERE studentId = :studentId")
    suspend fun deleteAttendanceByStudent(studentId: Int)

    @Query("SELECT COUNT(*) FROM attendance WHERE studentId = :studentId AND date BETWEEN :startDate AND :endDate AND isPresent = 1")
    suspend fun getPresentDaysCount(studentId: Int, startDate: String, endDate: String): Int

    @Query("SELECT COUNT(*) FROM attendance WHERE studentId = :studentId AND date BETWEEN :startDate AND :endDate")
    suspend fun getTotalDaysCount(studentId: Int, startDate: String, endDate: String): Int

    @Query("SELECT COUNT(*) FROM attendance WHERE studentId = :studentId AND isPresent = 0 AND date = :date")
    suspend fun getAbsentCountByDate(studentId: Int, date: String): Int

    // Метод для получения посещаемости по классу и дате
    @Query("SELECT * FROM attendance WHERE date = :date AND studentId IN (SELECT id FROM students WHERE className = :className)")
    fun getAttendanceByClassAndDate(className: String, date: String): Flow<List<Attendance>>
}
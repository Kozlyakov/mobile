package com.example.electronicjournal.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.electronicjournal.data.dao.AttendanceDao
import com.example.electronicjournal.data.dao.GradeDao
import com.example.electronicjournal.data.dao.HomeworkDao
import com.example.electronicjournal.data.dao.LessonDao
import com.example.electronicjournal.data.dao.ScheduleDao
import com.example.electronicjournal.data.dao.SubjectDao
import com.example.electronicjournal.data.dao.UserDao
import com.example.electronicjournal.data.model.Attendance
import com.example.electronicjournal.data.model.Grade
import com.example.electronicjournal.data.model.Homework
import com.example.electronicjournal.data.model.Lesson
import com.example.electronicjournal.data.model.Schedule
import com.example.electronicjournal.data.model.Student
import com.example.electronicjournal.data.model.Subject
import com.example.electronicjournal.data.model.User

@Database(
    entities = [
        User::class,
        Schedule::class,
        Subject::class,
        Grade::class,
        Homework::class,
        Student::class,
        Attendance::class,
        Lesson::class       // Добавлено
    ],
    version = 4,  // Увеличена версия с 2 до 3
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun subjectDao(): SubjectDao
    abstract fun gradeDao(): GradeDao
    abstract fun homeworkDao(): HomeworkDao
    abstract fun studentDao(): StudentDao      // Добавлено
    abstract fun attendanceDao(): AttendanceDao // Добавлено
    abstract fun lessonDao(): LessonDao        // Добавлено

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "electronic_journal_db"
                ).fallbackToDestructiveMigration() // Очистит старую базу и создаст новую
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
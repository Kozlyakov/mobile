package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.HomeworkDao
import com.example.electronicjournal.data.model.Homework
import kotlinx.coroutines.flow.Flow

class HomeworkRepository(private val homeworkDao: HomeworkDao) {

    fun getHomeworkByClass(classId: Int): Flow<List<Homework>> {
        return homeworkDao.getHomeworkByClass(classId)
    }

    suspend fun addHomework(homework: Homework) {
        homeworkDao.insertHomework(homework)
    }

    suspend fun initializeSampleData() {
        homeworkDao.deleteAllHomework()

        val sampleHomework = listOf(
            Homework(classId = 1, subjectId = 1, description = "Решить задачи №15-20 из учебника", dueDate = "2024-01-22", assignmentDate = "2024-01-18"),
            Homework(classId = 1, subjectId = 2, description = "Подготовить доклад по теме 'Электричество'", dueDate = "2024-01-25", assignmentDate = "2024-01-19"),
            Homework(classId = 1, subjectId = 3, description = "Прочитать параграф 15, ответить на вопросы", dueDate = "2024-01-20", assignmentDate = "2024-01-17", isCompleted = true)
        )

        homeworkDao.insertAllHomework(sampleHomework)
    }
}
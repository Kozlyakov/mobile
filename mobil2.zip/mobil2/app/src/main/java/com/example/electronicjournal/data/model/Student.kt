package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey val id: Int,
    val name: String,
    val className: String,
    val email: String? = null,
    val phone: String? = null,
    val parentPhone: String? = null,
    val photoUrl: String = "",
    val isActive: Boolean = true
)
package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "schedule")
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,

    val classId: Int,
    val subject: String,
    val teacher: String,
    val dayOfWeek: Int,
    val lessonNumber: Int,
    val classroom: String
)

package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.UserDao
import com.example.electronicjournal.data.model.User
import kotlinx.coroutines.flow.Flow

class UserRepository(private val userDao: UserDao) {

    suspend fun authenticate(login: String, password: String): User? {
        return userDao.getUserByCredentials(login, password)
    }

    suspend fun getUserByLogin(login: String): User? {
        return userDao.getUserByLogin(login)
    }

    suspend fun getUserById(id: Int): User? {
        return userDao.getUserById(id)
    }

    fun getUsersByType(type: String): Flow<List<User>> {
        return userDao.getUsersByType(type)
    }

    suspend fun addUser(user: User) {
        userDao.insertUser(user)
    }

    suspend fun deleteUser(login: String) {
        userDao.deleteUser(login)
    }

    // 👉 наша функция с демо-пользователями
    suspend fun initializeSampleData() {
        userDao.deleteAllUsers()

        val sample = listOf(
            // Ученик
            User(
                id = 1,
                login = "student1",
                password = "1234",
                firstName = "Иван",
                lastName = "Иванов",
                userType = "student",
                email = "student1@mail.ru",
                phone = "+79991111111",
                className = "9А"
            ),
            // Преподаватель
            User(
                id = 2,
                login = "teacher1",
                password = "1234",
                firstName = "Анна",
                lastName = "Сидорова",
                userType = "teacher",
                email = "teacher@mail.ru",
                phone = "+79992222222",
                className = null
            ),
            // Родитель
            User(
                id = 3,
                login = "parent1",
                password = "1234",
                firstName = "Павел",
                lastName = "Иванов",
                userType = "parent",
                email = "parent@mail.ru",
                phone = "+79993333333",
                className = null
            ),
            // Админ
            User(
                id = 4,
                login = "admin",
                password = "admin",
                firstName = "Главный",
                lastName = "Админ",
                userType = "admin",
                email = "admin@school.ru",
                phone = "+79994444444",
                className = null
            )
        )

        userDao.insertAllUsers(sample)
    }
}

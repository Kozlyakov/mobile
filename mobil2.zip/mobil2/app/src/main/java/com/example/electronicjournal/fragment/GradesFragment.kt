package com.example.electronicjournal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.electronicjournal.adapter.GradesAdapter
import com.example.electronicjournal.databinding.FragmentGradesBinding

class GradesFragment : Fragment() {

    private var _binding: FragmentGradesBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: GradesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentGradesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        adapter = GradesAdapter(emptyList())
        binding.rvGrades.layoutManager = LinearLayoutManager(requireContext())
        binding.rvGrades.adapter = adapter

        binding.btnFilterSubject.setOnClickListener {
            Toast.makeText(requireContext(), "Выберите предмет (заглушка)", Toast.LENGTH_SHORT).show()
        }

        binding.btnFilterPeriod.setOnClickListener {
            Toast.makeText(requireContext(), "Выберите период (заглушка)", Toast.LENGTH_SHORT).show()
        }

        binding.fabAddGrade.setOnClickListener {
            Toast.makeText(requireContext(), "Добавить оценку (заглушка)", Toast.LENGTH_SHORT).show()
        }

        adapter.onSubjectClick = { subject ->
            Toast.makeText(requireContext(), "Открыть предмет: $subject", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

package com.example.electronicjournal.data.database

import androidx.room.*
import com.example.electronicjournal.data.model.Student
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {

    @Query("SELECT * FROM students WHERE className = :className ORDER BY name")
    fun getStudentsByClass(className: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id = :studentId")
    suspend fun getStudentById(studentId: Int): Student?

    @Query("SELECT * FROM students WHERE name LIKE '%' || :searchQuery || '%'")
    fun searchStudents(searchQuery: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE name LIKE '%' || :searchQuery || '%' AND className = :className")
    fun searchStudentsInClass(searchQuery: String, className: String): Flow<List<Student>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllStudents(students: List<Student>)

    @Update
    suspend fun updateStudent(student: Student)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("DELETE FROM students WHERE id = :studentId")
    suspend fun deleteStudentById(studentId: Int)

    @Query("DELETE FROM students WHERE className = :className")
    suspend fun deleteStudentsByClass(className: String)

    @Query("SELECT COUNT(*) FROM students WHERE className = :className")
    suspend fun getStudentCountByClass(className: String): Int

    @Query("SELECT COUNT(*) FROM students")
    suspend fun getTotalStudentCount(): Int

    @Query("SELECT DISTINCT className FROM students ORDER BY className")
    fun getAllClasses(): Flow<List<String>>

    @Query("SELECT * FROM students WHERE isActive = 1 AND className = :className")
    fun getActiveStudentsByClass(className: String): Flow<List<Student>>

    @Query("UPDATE students SET isActive = :isActive WHERE id = :studentId")
    suspend fun updateStudentStatus(studentId: Int, isActive: Boolean)
}
package com.example.electronicjournal.ui.teacher.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.electronicjournal.R
import com.example.electronicjournal.data.model.Student

class StudentGradesTableAdapter(
    private var students: List<Student> = emptyList(),
    private var grades: Map<Int, List<Int>> = emptyMap(), // studentId -> list of grades
    private var attendance: Map<Int, Boolean> = emptyMap() // studentId -> isPresent
) : RecyclerView.Adapter<StudentGradesTableAdapter.StudentViewHolder>() {

    var onGradeClick: ((Student, Int?) -> Unit)? = null
    var onAttendanceClick: ((Student, Boolean) -> Unit)? = null

    class StudentViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvStudentName: TextView = itemView.findViewById(R.id.tvStudentName)
        val tvGrades: TextView = itemView.findViewById(R.id.tvGrades)
        val tvAttendance: TextView = itemView.findViewById(R.id.tvAttendance)
        val tvAverage: TextView = itemView.findViewById(R.id.tvAverage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StudentViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_student_grades_table, parent, false)
        return StudentViewHolder(view)
    }

    override fun onBindViewHolder(holder: StudentViewHolder, position: Int) {
        val student = students[position]
        val studentGrades = grades[student.id] ?: emptyList()
        val isPresent = attendance[student.id] ?: true

        // Установка имени ученика
        holder.tvStudentName.text = student.name

        // Отображение оценок
        val gradesText = if (studentGrades.isNotEmpty()) {
            studentGrades.joinToString(", ")
        } else {
            "—"
        }
        holder.tvGrades.text = gradesText

        // Подсветка оценок цветами
        if (studentGrades.isNotEmpty()) {
            val average = studentGrades.average()
            holder.tvAverage.text = "%.1f".format(average)

            // Цвет средней оценки
            val color = when {
                average >= 4.5 -> R.color.grade_5
                average >= 3.5 -> R.color.grade_4
                average >= 2.5 -> R.color.grade_3
                else -> R.color.grade_2
            }
            holder.tvAverage.setTextColor(ContextCompat.getColor(holder.itemView.context, color))
        } else {
            holder.tvAverage.text = "—"
        }

        // Отображение посещаемости
        holder.tvAttendance.text = if (isPresent) "✓" else "✗"
        val attendanceColor = if (isPresent) R.color.success_color else R.color.error_color
        holder.tvAttendance.setTextColor(ContextCompat.getColor(holder.itemView.context, attendanceColor))

        // Обработчики кликов
        holder.tvGrades.setOnClickListener {
            onGradeClick?.invoke(student, if (studentGrades.isNotEmpty()) studentGrades.last() else null)
        }

        holder.tvAttendance.setOnClickListener {
            onAttendanceClick?.invoke(student, isPresent)
        }
    }

    override fun getItemCount(): Int = students.size

    fun updateData(
        newStudents: List<Student>,
        newGrades: Map<Int, List<Int>>,
        newAttendance: Map<Int, Boolean>
    ) {
        students = newStudents
        grades = newGrades
        attendance = newAttendance
        notifyDataSetChanged()
    }

    fun updateGrade(studentId: Int, grade: Int) {
        val currentGrades = grades[studentId]?.toMutableList() ?: mutableListOf()
        currentGrades.add(grade)

        // Создаем новую карту с обновленными оценками
        val updatedGrades = grades.toMutableMap()
        updatedGrades[studentId] = currentGrades
        grades = updatedGrades

        notifyDataSetChanged()
    }

    fun updateAttendance(studentId: Int, isPresent: Boolean) {
        val updatedAttendance = attendance.toMutableMap()
        updatedAttendance[studentId] = isPresent
        attendance = updatedAttendance
        notifyDataSetChanged()
    }

    // Новый метод для получения всех оценок
    fun getGrades(): Map<Int, List<Int>> {
        return grades
    }

    // Метод для получения новых оценок (только последние добавленные)
    fun getNewGrades(): Map<Int, Int> {
        return grades.mapValues { (_, gradeList) ->
            gradeList.lastOrNull() ?: 0
        }.filter { (_, grade) -> grade > 0 }
    }

    // === ДОБАВЛЕННЫЕ МЕТОДЫ ДОСТУПА ===

    /**
     * Получить список всех студентов
     */
    fun getStudents(): List<Student> {
        return students
    }

    /**
     * Получить карту посещаемости
     */
    fun getAttendance(): Map<Int, Boolean> {
        return attendance
    }

    /**
     * Получить студента по ID
     */
    fun getStudentById(studentId: Int): Student? {
        return students.find { it.id == studentId }
    }

    /**
     * Получить оценки конкретного студента
     */
    fun getStudentGrades(studentId: Int): List<Int> {
        return grades[studentId] ?: emptyList()
    }

    /**
     * Получить статус посещаемости студента
     */
    fun getStudentAttendance(studentId: Int): Boolean {
        return attendance[studentId] ?: true
    }

    /**
     * Получить средний балл студента
     */
    fun getStudentAverage(studentId: Int): Double {
        val studentGrades = grades[studentId] ?: emptyList()
        return if (studentGrades.isNotEmpty()) {
            studentGrades.average()
        } else {
            0.0
        }
    }

    /**
     * Получить количество студентов
     */
    fun getStudentCount(): Int {
        return students.size
    }

    /**
     * Получить количество студентов с оценками
     */
    fun getStudentsWithGradesCount(): Int {
        return grades.count { it.value.isNotEmpty() }
    }

    /**
     * Получить количество отсутствующих студентов
     */
    fun getAbsentStudentsCount(): Int {
        return attendance.count { !it.value }
    }

    /**
     * Получить общее количество выставленных оценок
     */
    fun getTotalGradesCount(): Int {
        return grades.values.sumOf { it.size }
    }

    /**
     * Проверить, есть ли оценки у студента
     */
    fun hasGrades(studentId: Int): Boolean {
        return grades[studentId]?.isNotEmpty() ?: false
    }

    /**
     * Получить последнюю оценку студента
     */
    fun getLastGrade(studentId: Int): Int? {
        return grades[studentId]?.lastOrNull()
    }

    /**
     * Очистить все оценки (только в адаптере, не в базе)
     */
    fun clearAllGrades() {
        grades = emptyMap()
        notifyDataSetChanged()
    }

    /**
     * Очистить оценки конкретного студента
     */
    fun clearStudentGrades(studentId: Int) {
        val updatedGrades = grades.toMutableMap()
        updatedGrades[studentId] = emptyList()
        grades = updatedGrades
        notifyDataSetChanged()
    }
}
package com.example.electronicjournal.util

import android.content.Context
import android.content.SharedPreferences

class PreferenceHelper(context: Context) {

    companion object {
        const val ROLE_STUDENT = "student"
        const val ROLE_TEACHER = "teacher"
        const val ROLE_PARENT = "parent"
        const val ROLE_ADMIN = "admin"

        // Ключи для хранения данных
        private const val KEY_SAVED_LOGIN = "saved_login"
        private const val KEY_USER_TYPE = "user_type"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_CLASS_ID = "class_id"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_CLASS_NAME = "class_name"
        private const val KEY_EMAIL = "user_email"
        private const val KEY_PHONE = "user_phone"
    }

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("electronic_journal_prefs", Context.MODE_PRIVATE)

    // ---------- LOGIN ----------
    fun saveUserCredentials(login: String) {
        sharedPreferences.edit().putString(KEY_SAVED_LOGIN, login).apply()
    }

    fun getSavedLogin(): String {
        return sharedPreferences.getString(KEY_SAVED_LOGIN, "") ?: ""
    }

    // ---------- ROLE ----------
    fun saveUserType(userType: String) {
        sharedPreferences.edit().putString(KEY_USER_TYPE, userType).apply()
    }

    fun getUserType(): String {
        return sharedPreferences.getString(KEY_USER_TYPE, ROLE_STUDENT) ?: ROLE_STUDENT
    }

    // ---------- USER ID ----------
    fun saveUserId(userId: Int) {
        sharedPreferences.edit().putInt(KEY_USER_ID, userId).apply()
    }

    fun getUserId(): Int {
        return sharedPreferences.getInt(KEY_USER_ID, 0)
    }

    // ---------- CLASS ID ----------
    fun saveClassId(classId: Int) {
        sharedPreferences.edit().putInt(KEY_CLASS_ID, classId).apply()
    }

    fun getClassId(): Int {
        return sharedPreferences.getInt(KEY_CLASS_ID, 0)
    }

    // ---------- USER NAME ----------
    fun saveUserName(userName: String) {
        sharedPreferences.edit().putString(KEY_USER_NAME, userName).apply()
    }

    fun getUserName(): String {
        return sharedPreferences.getString(KEY_USER_NAME, "") ?: ""
    }

    // ---------- CLASS NAME ----------
    fun saveClassName(className: String) {
        sharedPreferences.edit().putString(KEY_CLASS_NAME, className).apply()
    }

    fun getClassName(): String {
        return sharedPreferences.getString(KEY_CLASS_NAME, "") ?: ""
    }

    // ---------- EMAIL ----------
    fun saveEmail(email: String) {
        sharedPreferences.edit().putString(KEY_EMAIL, email).apply()
    }

    fun getEmail(): String {
        return sharedPreferences.getString(KEY_EMAIL, "") ?: ""
    }

    // ---------- PHONE ----------
    fun savePhone(phone: String) {
        sharedPreferences.edit().putString(KEY_PHONE, phone).apply()
    }

    fun getPhone(): String {
        return sharedPreferences.getString(KEY_PHONE, "") ?: ""
    }

    // ---------- CLEAR ----------
    fun clearCredentials() {
        sharedPreferences.edit().clear().apply()
    }

    // ---------- UTILS ----------
    fun isStudent(): Boolean = getUserType() == ROLE_STUDENT
    fun isTeacher(): Boolean = getUserType() == ROLE_TEACHER
    fun isParent(): Boolean = getUserType() == ROLE_PARENT
    fun isAdmin(): Boolean = getUserType() == ROLE_ADMIN

    fun getRoleDisplayName(): String {
        return when (getUserType()) {
            ROLE_STUDENT -> "Ученик"
            ROLE_TEACHER -> "Преподаватель"
            ROLE_PARENT -> "Родитель"
            ROLE_ADMIN -> "Администратор"
            else -> "Пользователь"
        }
    }
}
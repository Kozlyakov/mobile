package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lessons")
data class Lesson(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val subjectId: Int,
    val className: String,
    val dayOfWeek: Int, // 1-понедельник, 7-воскресенье
    val lessonNumber: Int, // 1-8
    val classroom: String,
    val teacherId: Int
)
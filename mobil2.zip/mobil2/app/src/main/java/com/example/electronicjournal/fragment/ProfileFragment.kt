package com.example.electronicjournal.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.electronicjournal.R
import com.example.electronicjournal.activity.LoginActivity
import com.example.electronicjournal.data.database.AppDatabase
import com.example.electronicjournal.data.model.User
import com.example.electronicjournal.data.repository.UserRepository
import com.example.electronicjournal.databinding.FragmentProfileBinding
import com.example.electronicjournal.util.PreferenceHelper
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var preferenceHelper: PreferenceHelper
    private lateinit var userRepository: UserRepository
    private var currentUser: User? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        preferenceHelper = PreferenceHelper(requireContext())

        // Инициализация репозитория
        val database = AppDatabase.getInstance(requireContext())
        userRepository = UserRepository(database.userDao())

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadUserData()
        setupClickListeners()
    }

    private fun loadUserData() {
        lifecycleScope.launch {
            try {
                val userId = preferenceHelper.getUserId()
                currentUser = userRepository.getUserById(userId)

                currentUser?.let { user ->
                    // Заполняем данные профиля - используем правильные ID из XML
                    binding.tvName.text = "${user.firstName} ${user.lastName}"
                    binding.tvRole.text = when (user.userType) {
                        PreferenceHelper.ROLE_STUDENT -> "Ученик"
                        PreferenceHelper.ROLE_TEACHER -> "Преподаватель"
                        PreferenceHelper.ROLE_PARENT -> "Родитель"
                        PreferenceHelper.ROLE_ADMIN -> "Администратор"
                        else -> "Пользователь"
                    }

                    binding.tvClass.text = user.className ?: "Не указан"
                    binding.tvLogin.text = user.login
                    binding.tvEmail.text = user.email ?: "Не указан"
                    binding.tvPhone.text = user.phone ?: "Не указан"

                    // Показываем класс только для студентов
                    if (user.userType != PreferenceHelper.ROLE_STUDENT) {
                        binding.llClassInfo.visibility = View.GONE
                    }

                    // Для учителей показываем предмет (временно убираем, т.к. нет поля subject)
                    if (user.userType == PreferenceHelper.ROLE_TEACHER) {
                        binding.llSubjectInfo.visibility = View.VISIBLE
                        // Временно используем заглушку, т.к. в модели User нет поля subject
                        binding.tvSubject.text = "Математика" // Заглушка
                    }

                    // Расчет статистики
                    calculateStatistics(user)
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Ошибка загрузки данных", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun calculateStatistics(user: User) {
        // Статистика для разных типов пользователей
        when (user.userType) {
            PreferenceHelper.ROLE_STUDENT -> {
                binding.tvAverageGrade.text = "4.5"
                binding.tvTotalGrades.text = "24"
                binding.tvAttendance.text = "95%"
            }
            PreferenceHelper.ROLE_TEACHER -> {
                binding.tvAverageGrade.text = "4.2"
                binding.tvTotalGrades.text = "156"
                binding.tvAttendance.text = "32"
            }
            PreferenceHelper.ROLE_ADMIN -> {
                binding.tvAverageGrade.text = "4.3"
                binding.tvTotalGrades.text = "89"
                binding.tvAttendance.text = "100%"
            }
            PreferenceHelper.ROLE_PARENT -> {
                binding.tvAverageGrade.text = "4.4"
                binding.tvTotalGrades.text = "18"
                binding.tvAttendance.text = "92%"
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnSettings.setOnClickListener {
            showSettingsDialog()
        }

        binding.btnChangePassword.setOnClickListener {
            showChangePasswordDialog()
        }

        binding.btnHelp.setOnClickListener {
            showHelpDialog()
        }

        binding.btnLogout.setOnClickListener {
            logout()
        }

        // Клики по статистике
        binding.llPerformanceStats.setOnClickListener {
            showStatisticsDetails()
        }
    }

    private fun showSettingsDialog() {
        val items = arrayOf("Уведомления", "Тема оформления", "Язык", "Конфиденциальность")
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Настройки")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> Toast.makeText(requireContext(), "Настройки уведомлений", Toast.LENGTH_SHORT).show()
                    1 -> Toast.makeText(requireContext(), "Смена темы", Toast.LENGTH_SHORT).show()
                    2 -> Toast.makeText(requireContext(), "Выбор языка", Toast.LENGTH_SHORT).show()
                    3 -> Toast.makeText(requireContext(), "Настройки конфиденциальности", Toast.LENGTH_SHORT).show()
                }
            }
            .setPositiveButton("Закрыть", null)
            .show()
    }

    private fun showChangePasswordDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_change_password, null)

        val etNewPassword = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etNewPassword)
        val etConfirmPassword = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etConfirmPassword)

        val dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Смена пароля")
            .setView(dialogView)
            .setPositiveButton("Сменить") { _, _ ->
                val newPassword = etNewPassword.text.toString()
                val confirmPassword = etConfirmPassword.text.toString()

                if (validatePasswordChange(newPassword, confirmPassword)) {
                    // Здесь будет логика смены пароля
                    changePassword()
                }
            }
            .setNegativeButton("Отмена", null)
            .create()

        dialog.show()
    }

    private fun validatePasswordChange(newPassword: String, confirmPassword: String): Boolean {
        if (newPassword.length < 6) {
            Toast.makeText(requireContext(), "Новый пароль должен быть не менее 6 символов", Toast.LENGTH_SHORT).show()
            return false
        }

        if (newPassword != confirmPassword) {
            Toast.makeText(requireContext(), "Пароли не совпадают", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun changePassword() {
        lifecycleScope.launch {
            try {
                // Здесь должна быть реальная логика смены пароля
                // Пока используем заглушку
                Toast.makeText(requireContext(), "Пароль успешно изменен", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Ошибка при смене пароля", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showHelpDialog() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Помощь")
            .setMessage("Электронный журнал v1.0\n\nДля получения помощи обращайтесь в техническую поддержку:\nsupport@school.ru")
            .setPositiveButton("ОК", null)
            .show()
    }

    private fun showStatisticsDetails() {
        val message = when (preferenceHelper.getUserType()) {
            PreferenceHelper.ROLE_STUDENT -> "Подробная статистика ваших оценок"
            PreferenceHelper.ROLE_TEACHER -> "Статистика оценок ваших учеников"
            PreferenceHelper.ROLE_ADMIN -> "Общая статистика системы"
            else -> "Статистика"
        }
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    private fun logout() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Выход")
            .setMessage("Вы уверены, что хотите выйти?")
            .setPositiveButton("Да") { _, _ ->
                preferenceHelper.clearCredentials()
                startActivity(Intent(requireContext(), LoginActivity::class.java))
                requireActivity().finish()
                Toast.makeText(requireContext(), "Вы вышли из системы", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
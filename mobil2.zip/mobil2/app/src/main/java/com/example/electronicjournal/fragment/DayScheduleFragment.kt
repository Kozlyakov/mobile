package com.example.electronicjournal.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.electronicjournal.adapter.ScheduleAdapter
import com.example.electronicjournal.data.model.Schedule
import com.example.electronicjournal.databinding.FragmentSchedulePageBinding

private const val ARG_DAY_INDEX = "day_index"

class DayScheduleFragment : Fragment() {

    private var dayIndex: Int = 0
    private var _binding: FragmentSchedulePageBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ScheduleAdapter

    companion object {
        fun newInstance(dayIndex: Int): DayScheduleFragment {
            val fragment = DayScheduleFragment()
            val args = Bundle()
            args.putInt(ARG_DAY_INDEX, dayIndex)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            dayIndex = it.getInt(ARG_DAY_INDEX, 0)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSchedulePageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: android.os.Bundle?) {
        adapter = ScheduleAdapter(emptyList(), "student",
            onAttendanceClick = { lesson ->
                // Use lesson.lessonNumber since Schedule doesn't have subject name
                Toast.makeText(requireContext(), "Отметка посещения: урок ${lesson.lessonNumber}", Toast.LENGTH_SHORT).show()
            },
            onAddGradeClick = { lesson ->
                Toast.makeText(requireContext(), "Добавить оценку: урок ${lesson.lessonNumber}", Toast.LENGTH_SHORT).show()
            },
            onAddHomeworkClick = { lesson ->
                Toast.makeText(requireContext(), "Добавить ДЗ: урок ${lesson.lessonNumber}", Toast.LENGTH_SHORT).show()
            })
        binding.rvSchedulePage.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSchedulePage.adapter = adapter

        // TODO: load real data for the day (dayIndex) from repository
        // For demo, we can create mock data
        val demoList = listOf<Schedule>()
        adapter.updateData(demoList.map { Pair(it, "Предмет") })

        Toast.makeText(requireContext(), "Загружаем уроки для дня: ${dayIndex+1}", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

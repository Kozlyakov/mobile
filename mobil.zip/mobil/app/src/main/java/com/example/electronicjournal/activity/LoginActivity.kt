package com.example.electronicjournal.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.electronicjournal.MainActivity
import com.example.electronicjournal.data.AppDatabase
import com.example.electronicjournal.data.model.User
import com.example.electronicjournal.data.repository.GradeRepository
import com.example.electronicjournal.data.repository.SubjectRepository
import com.example.electronicjournal.data.repository.UserRepository
import com.example.electronicjournal.databinding.ActivityLoginBinding
import com.example.electronicjournal.util.PreferenceHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var etLogin: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var cbRememberMe: CheckBox
    private lateinit var btnLogin: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var tvForgotPassword: TextView
    private lateinit var tvRegister: TextView

    private lateinit var userRepository: UserRepository
    private lateinit var gradeRepository: GradeRepository
    private lateinit var subjectRepository: SubjectRepository
    private lateinit var preferenceHelper: PreferenceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Инициализация элементов
        initViews()

        // Инициализация базы данных и репозиториев
        val database = AppDatabase.Companion.getInstance(this)
        userRepository = UserRepository(database.userDao())
        gradeRepository = GradeRepository(database.gradeDao())
        subjectRepository = SubjectRepository(database.subjectDao())
        preferenceHelper = PreferenceHelper(this)

        // Загрузка сохраненных данных
        loadSavedCredentials()

        // Настройка кликов
        setupClickListeners()

        // Инициализация тестовых данных
        initializeSampleData()
    }

    private fun initViews() {
        etLogin = binding.etLogin
        etPassword = binding.etPassword
        cbRememberMe = binding.cbRememberMe
        btnLogin = binding.btnLogin
        progressBar = binding.progressBar
        tvForgotPassword = binding.tvForgotPassword
        tvRegister = binding.tvRegister
    }

    private fun loadSavedCredentials() {
        val savedLogin = preferenceHelper.getSavedLogin()
        if (savedLogin.isNotEmpty()) {
            etLogin.setText(savedLogin)
            cbRememberMe.isChecked = true
        }
    }

    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            attemptLogin()
        }

        tvForgotPassword.setOnClickListener {
            showForgotPasswordDialog()
        }

        tvRegister.setOnClickListener {
            showRegistrationDialog()
        }

        // Обработка нажатия Enter в поле пароля
        etPassword.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                attemptLogin()
                true
            } else {
                false
            }
        }
    }

    private fun attemptLogin() {
        val login = etLogin.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (validateInput(login, password)) {
            performLogin(login, password)
        }
    }

    private fun validateInput(login: String, password: String): Boolean {
        if (login.isEmpty()) {
            etLogin.error = "Введите логин"
            return false
        }

        if (password.isEmpty()) {
            etPassword.error = "Введите пароль"
            return false
        }

        if (password.length < 4) {
            etPassword.error = "Пароль должен содержать минимум 4 символа"
            return false
        }

        return true
    }

    private fun performLogin(login: String, password: String) {
        showLoading(true)

        lifecycleScope.launch {
            try {
                val user = userRepository.authenticate(login, password)

                if (user != null) {
                    // Сохраняем логин если отмечено "Запомнить меня"
                    if (cbRememberMe.isChecked) {
                        preferenceHelper.saveUserCredentials(login)
                    } else {
                        preferenceHelper.clearCredentials()
                    }

                    // Сохраняем данные пользователя
                    preferenceHelper.saveUserId(user.id)
                    preferenceHelper.saveUserType(user.userType)

                    runOnUiThread {
                        showLoading(false)
                        navigateToMainActivity(user)
                    }
                } else {
                    runOnUiThread {
                        showLoading(false)
                        showLoginError()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showLoading(false)
                    showNetworkError()
                }
            }
        }
    }

    private fun navigateToMainActivity(user: User) {
        val intent = Intent(this@LoginActivity, MainActivity::class.java)
        intent.putExtra("USER_ID", user.id)
        intent.putExtra("USER_TYPE", user.userType)
        intent.putExtra("USER_NAME", "${user.firstName} ${user.lastName}")
        intent.putExtra("CLASS_NAME", user.className ?: "")
        startActivity(intent)
        finish()

        Toast.makeText(this, "Добро пожаловать, ${user.firstName}!", Toast.LENGTH_SHORT).show()
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        btnLogin.isEnabled = !show
        btnLogin.text = if (show) "" else "Войти"
    }

    private fun showLoginError() {
        Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_LONG).show()
        etPassword.text?.clear()
        etPassword.requestFocus()
    }

    private fun showNetworkError() {
        Toast.makeText(this, "Ошибка сети. Проверьте подключение", Toast.LENGTH_LONG).show()
    }

    private fun showForgotPasswordDialog() {
        Toast.makeText(this, "Функция восстановления пароля в разработке", Toast.LENGTH_SHORT).show()
    }

    private fun showRegistrationDialog() {
        Toast.makeText(this, "Функция регистрации в разработке", Toast.LENGTH_SHORT).show()
    }

    private fun initializeSampleData() {
        lifecycleScope.launch {
            userRepository.initializeSampleData()
            subjectRepository.initializeSampleData()
            gradeRepository.initializeSampleGrades()
        }
    }
}
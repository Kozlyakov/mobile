package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.SubjectDao
import com.example.electronicjournal.data.model.Subject
import kotlinx.coroutines.flow.Flow

class SubjectRepository(private val subjectDao: SubjectDao) {

    fun getAllSubjects(): Flow<List<Subject>> {
        return subjectDao.getAllSubjects()
    }

    suspend fun getSubjectById(subjectId: Int): Subject? {
        return subjectDao.getSubjectById(subjectId)
    }

    suspend fun initializeSampleData() {
        subjectDao.deleteAllSubjects()

        val sampleSubjects = listOf(
            Subject(1, "Математика", "Матем"),
            Subject(2, "Физика", "Физ"),
            Subject(3, "История", "Ист"),
            Subject(4, "Литература", "Лит"),
            Subject(5, "Физкультура", "Физра")
        )

        subjectDao.insertAllSubjects(sampleSubjects)
    }
}
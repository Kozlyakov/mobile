package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "homework")
data class Homework(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val classId: Int,
    val subjectId: Int,
    val description: String,
    val dueDate: String,
    val assignmentDate: String,
    val isCompleted: Boolean = false
)
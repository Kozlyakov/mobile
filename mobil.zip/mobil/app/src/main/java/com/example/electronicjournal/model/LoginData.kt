package com.example.electronicjournal.model

data class LoginData(
    val login: String,
    val password: String,
    val rememberMe: Boolean = false
)
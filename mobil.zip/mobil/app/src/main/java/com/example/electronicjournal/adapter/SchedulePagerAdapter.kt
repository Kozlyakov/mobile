package com.example.electronicjournal.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.electronicjournal.fragment.DayScheduleFragment

class SchedulePagerAdapter(fragmentActivity: FragmentActivity, private val daysCount: Int) :
    FragmentStateAdapter(fragmentActivity) {

    override fun getItemCount(): Int = daysCount

    override fun createFragment(position: Int): Fragment {
        // position: 0..daysCount-1 (Mon..Sat)
        return DayScheduleFragment.newInstance(position)
    }
}

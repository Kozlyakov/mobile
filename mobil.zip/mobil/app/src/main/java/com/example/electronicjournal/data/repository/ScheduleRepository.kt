package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.ScheduleDao
import com.example.electronicjournal.data.model.Schedule
import kotlinx.coroutines.flow.Flow

class ScheduleRepository(private val scheduleDao: ScheduleDao) {

    fun getScheduleByClassAndDay(classId: Int, dayOfWeek: Int): Flow<List<Schedule>> {
        return scheduleDao.getScheduleByClassAndDay(classId, dayOfWeek)
    }

    suspend fun initializeSampleData() {
        scheduleDao.deleteAllSchedules()

        // Расписание для 9А класса
        val sampleSchedule = listOf(
            Schedule(classId = 1, subjectId = 1, dayOfWeek = 1, lessonNumber = 1, room = "каб. 301"),
            Schedule(classId = 1, subjectId = 2, dayOfWeek = 1, lessonNumber = 2, room = "каб. 205"),
            Schedule(classId = 1, subjectId = 3, dayOfWeek = 1, lessonNumber = 3, room = "каб. 104"),
            Schedule(classId = 1, subjectId = 1, dayOfWeek = 2, lessonNumber = 1, room = "каб. 301"),
            Schedule(classId = 1, subjectId = 4, dayOfWeek = 2, lessonNumber = 2, room = "каб. 208")
        )

        scheduleDao.insertAllSchedules(sampleSchedule)
    }
}
package com.example.electronicjournal.model

data class Grade(
    val id: Int = 0,
    val studentId: Int,
    val subject: String,
    val grade: Int,
    val gradeType: String, // "ответ", "дз", "тест", "контрольная"
    val date: String,
    val comment: String? = null
)
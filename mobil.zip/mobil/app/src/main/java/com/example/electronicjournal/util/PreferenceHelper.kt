package com.example.electronicjournal.util

import android.content.Context
import android.content.SharedPreferences

class PreferenceHelper(context: Context) {

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("electronic_journal_prefs", Context.MODE_PRIVATE)

    fun saveUserCredentials(login: String) {
        sharedPreferences.edit().putString("saved_login", login).apply()
    }

    fun getSavedLogin(): String {
        return sharedPreferences.getString("saved_login", "") ?: ""
    }

    fun saveUserType(userType: String) {
        sharedPreferences.edit().putString("user_type", userType).apply()
    }

    fun getUserType(): String {
        return sharedPreferences.getString("user_type", "student") ?: "student"
    }

    fun saveUserId(userId: Int) {
        sharedPreferences.edit().putInt("user_id", userId).apply()
    }

    fun getUserId(): Int {
        return sharedPreferences.getInt("user_id", 0)
    }

    fun clearCredentials() {
        sharedPreferences.edit().clear().apply()
    }
}
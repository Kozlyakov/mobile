package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "grades")
data class Grade(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val studentId: Int,
    val subjectId: Int,
    val grade: Int,
    val gradeType: String, // "ответ", "дз", "тест", "контрольная"
    val date: String,
    val comment: String? = null
)
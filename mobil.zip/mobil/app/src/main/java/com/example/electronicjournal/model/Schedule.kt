package com.example.electronicjournal.model

data class Schedule(
    val id: Int = 0,
    val dayOfWeek: String,
    val lessonNumber: Int,
    val subject: String,
    val teacher: String,
    val room: String? = null
)
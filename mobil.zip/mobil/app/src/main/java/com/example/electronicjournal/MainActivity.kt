package com.example.electronicjournal

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.electronicjournal.activity.LoginActivity
import com.example.electronicjournal.databinding.ActivityMainBinding
import com.example.electronicjournal.fragment.DashboardFragment
import com.example.electronicjournal.fragment.GradesFragment
import com.example.electronicjournal.fragment.HomeworkFragment
import com.example.electronicjournal.fragment.ProfileFragment
import com.example.electronicjournal.fragment.ScheduleFragment
import com.example.electronicjournal.ui.admin.AdminDashboardFragment
import com.example.electronicjournal.ui.student.StudentDashboardFragment
import com.example.electronicjournal.ui.teacher.TeacherDashboardFragment
import com.example.electronicjournal.ui.parent.ParentDashboardFragment
import com.example.electronicjournal.util.PreferenceHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var preferenceHelper: PreferenceHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preferenceHelper = PreferenceHelper(this)

        // Use the toolbar from layout
        setSupportActionBar(binding.toolbar)

        // Setup bottom navigation
        setupNavigation()

        // Load default fragment
        openFragment(DashboardFragment())

        // Adapt navigation for user type (student/teacher/parent)
        adaptNavigationForUserType()
    }

    private fun setupNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    openFragment(DashboardFragment())
                    true
                }
                R.id.nav_grades -> {
                    openFragment(GradesFragment())
                    true
                }
                R.id.nav_schedule -> {
                    openFragment(ScheduleFragment())
                    true
                }
                R.id.nav_homework -> {
                    openFragment(HomeworkFragment())
                    true
                }
                R.id.nav_profile -> {
                    openFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    fun openFragment(fragment: Fragment, addToBackStack: Boolean = false) {
        val transaction = supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
        if (addToBackStack) transaction.addToBackStack(null)
        transaction.commit()
    }

    private fun adaptNavigationForUserType() {
        val menu = binding.bottomNavigation.menu
        val userType = preferenceHelper.getUserType()
        // Example: if user is parent, hide schedule (optional)
        if (userType == "parent") {
            menu.findItem(R.id.nav_schedule)?.isVisible = false
        }
        // if teacher, keep all visible
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                Toast.makeText(this, "Настройки", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_help -> {
                Toast.makeText(this, "Раздел помощи", Toast.LENGTH_SHORT).show()
                true
            }
            R.id.action_logout -> {
                logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun logout() {
        preferenceHelper.clearCredentials()
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
        Toast.makeText(this, "Вы вышли из системы", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        // Если текущий фрагмент - главная страница, выходим из приложения
        val selected = binding.bottomNavigation.selectedItemId
        if (selected == R.id.nav_dashboard) {
            finishAffinity()
        } else {
            binding.bottomNavigation.selectedItemId = R.id.nav_dashboard
            openFragment(DashboardFragment())
        }
    }
}

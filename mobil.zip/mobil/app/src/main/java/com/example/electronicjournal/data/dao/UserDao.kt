package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

    @Query("SELECT * FROM users WHERE login = :login AND password = :password")
    suspend fun getUserByCredentials(login: String, password: String): User?

    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: Int): User?

    @Query("SELECT * FROM users WHERE userType = :userType")
    fun getUsersByType(userType: String): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllUsers(users: List<User>)

    @Query("DELETE FROM users")
    suspend fun deleteAllUsers()
}
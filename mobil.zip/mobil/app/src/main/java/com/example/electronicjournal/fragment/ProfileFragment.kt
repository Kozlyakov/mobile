package com.example.electronicjournal.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.electronicjournal.activity.LoginActivity
import com.example.electronicjournal.databinding.FragmentProfileBinding
import com.example.electronicjournal.util.PreferenceHelper

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private lateinit var preferenceHelper: PreferenceHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        preferenceHelper = PreferenceHelper(requireContext())
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.btnSettings.setOnClickListener {
            Toast.makeText(requireContext(), "Открыть настройки (заглушка)", Toast.LENGTH_SHORT).show()
        }
        binding.btnChangePassword.setOnClickListener {
            Toast.makeText(requireContext(), "Сменить пароль (заглушка)", Toast.LENGTH_SHORT).show()
        }
        binding.btnHelp.setOnClickListener {
            Toast.makeText(requireContext(), "Помощь (заглушка)", Toast.LENGTH_SHORT).show()
        }
        binding.btnLogout.setOnClickListener {
            logout()
        }
    }

    private fun logout() {
        preferenceHelper.clearCredentials()
        startActivity(Intent(requireContext(), LoginActivity::class.java))
        requireActivity().finish()
        Toast.makeText(requireContext(), "Вы вышли из системы", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

package com.example.electronicjournal.data.repository

import com.example.electronicjournal.data.dao.UserDao
import com.example.electronicjournal.data.model.User
import kotlinx.coroutines.flow.Flow

class UserRepository(private val userDao: UserDao) {

    suspend fun authenticate(login: String, password: String): User? {
        return userDao.getUserByCredentials(login, password)
    }

    suspend fun getUserById(userId: Int): User? {
        return userDao.getUserById(userId)
    }

    fun getUsersByType(userType: String): Flow<List<User>> {
        return userDao.getUsersByType(userType)
    }

    suspend fun insertUser(user: User) {
        userDao.insertUser(user)
    }

    suspend fun insertAllUsers(users: List<User>) {
        userDao.insertAllUsers(users)
    }

    suspend fun initializeSampleData() {
        // Очищаем старые данные
        userDao.deleteAllUsers()

        // Добавляем тестовых пользователей
        val sampleUsers = listOf(
            User(1, "student1", "1234", "Иван", "Иванов", "student", "student1@school.ru", "+79991112233", "9А"),
            User(2, "student2", "1234", "Мария", "Петрова", "student", "student2@school.ru", "+79992223344", "9А"),
            User(3, "teacher1", "1234", "Анна", "Сидорова", "teacher", "teacher1@school.ru", "+79993334455", null),
            User(4, "parent1", "1234", "Сергей", "Иванов", "parent", "parent1@mail.ru", "+79994445566", null)
        )

        userDao.insertAllUsers(sampleUsers)
    }

    // ensure admin user
    suspend fun ensureAdmin(){
        try {
            val existing = getUserByLogin("admin")
            if(existing==null){
                addUser(com.example.electronicjournal.data.model.User(login="admin", password="admin", userType="admin"))
            }
        } catch(e:Exception){ }
    }
}
    suspend fun deleteUser(login: String){ /* implement */ }

package com.example.electronicjournal.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.electronicjournal.R
import com.example.electronicjournal.data.model.Schedule

class ScheduleAdapter(
    private var scheduleWithSubjects: List<Pair<Schedule, String>>,
    private val userType: String,
    private val onAttendanceClick: (Schedule) -> Unit = {},
    private val onAddGradeClick: (Schedule) -> Unit = {},
    private val onAddHomeworkClick: (Schedule) -> Unit = {}
) : RecyclerView.Adapter<ScheduleAdapter.ScheduleViewHolder>() {

    class ScheduleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvLessonNumber: TextView = itemView.findViewById(R.id.tvLessonNumber)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val tvSubject: TextView = itemView.findViewById(R.id.tvSubject)
        val tvTeacher: TextView = itemView.findViewById(R.id.tvTeacher)
        val tvRoom: TextView = itemView.findViewById(R.id.tvRoom)
        val llHomeworkInfo: View = itemView.findViewById(R.id.llHomeworkInfo)
        val tvHomework: TextView = itemView.findViewById(R.id.tvHomework)
        val tvHomeworkDue: TextView = itemView.findViewById(R.id.tvHomeworkDue)
        val llCurrentLesson: View = itemView.findViewById(R.id.llCurrentLesson)
        val tvTimeLeft: TextView = itemView.findViewById(R.id.tvTimeLeft)
        val llTeacherActions: View = itemView.findViewById(R.id.llTeacherActions)
        val btnAttendance: View = itemView.findViewById(R.id.btnAttendance)
        val btnAddGrade: View = itemView.findViewById(R.id.btnAddGrade)
        val btnAddHomework: View = itemView.findViewById(R.id.btnAddHomework)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScheduleViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_schedule, parent, false)
        return ScheduleViewHolder(view)
    }

    override fun onBindViewHolder(holder: ScheduleViewHolder, position: Int) {
        val (lesson, subjectName) = scheduleWithSubjects[position]

        holder.tvLessonNumber.text = "${lesson.lessonNumber} урок"
        holder.tvTime.text = getLessonTime(lesson.lessonNumber)
        holder.tvSubject.text = subjectName
        holder.tvTeacher.text = getTeacherForSubject(subjectName)
        holder.tvRoom.text = lesson.room ?: "каб. ---"

        // Настраиваем дополнительные элементы
        setupHomeworkInfo(holder, lesson)
        setupCurrentLessonIndicator(holder, lesson)
        setupTeacherActions(holder, lesson)

        // Подсветка текущего урока
        if (isCurrentLesson(lesson.lessonNumber)) {
            holder.itemView.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.context, R.color.primary_light)
            )
        } else {
            holder.itemView.setBackgroundColor(
                ContextCompat.getColor(holder.itemView.context, R.color.white)
            )
        }
    }

    override fun getItemCount(): Int = scheduleWithSubjects.size

    fun updateData(newScheduleWithSubjects: List<Pair<Schedule, String>>) {
        scheduleWithSubjects = newScheduleWithSubjects
        notifyDataSetChanged()
    }

    private fun setupHomeworkInfo(holder: ScheduleViewHolder, _lesson: Schedule) {
        // TODO: Загрузить информацию о домашнем задании для этого урока
        val hasHomework = false // Заглушка
        if (hasHomework) {
            holder.llHomeworkInfo.visibility = View.VISIBLE
            holder.tvHomework.text = "Д/З: задачи стр. 45 №1-10"
            holder.tvHomeworkDue.text = "до 22.12"
        } else {
            holder.llHomeworkInfo.visibility = View.GONE
        }
    }

    private fun setupCurrentLessonIndicator(holder: ScheduleViewHolder, lesson: Schedule) {
        val isCurrent = isCurrentLesson(lesson.lessonNumber)
        if (isCurrent) {
            holder.llCurrentLesson.visibility = View.VISIBLE
            holder.tvTimeLeft.text = calculateTimeLeft(lesson.lessonNumber)
        } else {
            holder.llCurrentLesson.visibility = View.GONE
        }
    }

    private fun setupTeacherActions(holder: ScheduleViewHolder, lesson: Schedule) {
        if (userType == "teacher") {
            holder.llTeacherActions.visibility = View.VISIBLE
            holder.btnAttendance.setOnClickListener { onAttendanceClick(lesson) }
            holder.btnAddGrade.setOnClickListener { onAddGradeClick(lesson) }
            holder.btnAddHomework.setOnClickListener { onAddHomeworkClick(lesson) }
        } else {
            holder.llTeacherActions.visibility = View.GONE
        }
    }

    private fun getLessonTime(lessonNumber: Int): String {
        val lessonTimes = mapOf(
            1 to "8:30 - 9:15",
            2 to "9:25 - 10:10",
            3 to "10:20 - 11:05",
            4 to "11:20 - 12:05",
            5 to "12:20 - 13:05",
            6 to "13:15 - 14:00",
            7 to "14:10 - 14:55",
            8 to "15:05 - 15:50"
        )
        return lessonTimes[lessonNumber] ?: "--:-- - --:--"
    }

    private fun getTeacherForSubject(subject: String): String {
        val teachers = mapOf(
            "Математика" to "Сидорова А.С.",
            "Физика" to "Петров И.П.",
            "История" to "Иванова М.И.",
            "Литература" to "Козлов С.В.",
            "Физкультура" to "Смирнов А.А.",
            "Химия" to "Васильева О.Л.",
            "Биология" to "Николаев Д.К.",
            "Английский язык" to "Кузнецова Е.М."
        )
        return teachers[subject] ?: "Учитель"
    }

    private fun isCurrentLesson(_lessonNumber: Int): Boolean {
        // TODO: Реализовать проверку текущего урока
        // Это должна быть сложная логика с учетом дня недели и времени
        return false
    }

    private fun calculateTimeLeft(_lessonNumber: Int): String {
        // TODO: Реализовать расчет оставшегося времени
        return "15 мин"
    }
}
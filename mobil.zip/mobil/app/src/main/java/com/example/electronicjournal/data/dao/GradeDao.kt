package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.Grade
import kotlinx.coroutines.flow.Flow

@Dao
interface GradeDao {

    @Query("SELECT * FROM grades WHERE studentId = :studentId ORDER BY date DESC")
    fun getGradesByStudent(studentId: Int): Flow<List<Grade>>

    @Query("SELECT * FROM grades WHERE studentId = :studentId AND subjectId = :subjectId")
    fun getGradesByStudentAndSubject(studentId: Int, subjectId: Int): Flow<List<Grade>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrade(grade: Grade)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllGrades(grades: List<Grade>)

    @Query("DELETE FROM grades WHERE id = :gradeId")
    suspend fun deleteGrade(gradeId: Int)

    @Query("DELETE FROM grades")
    suspend fun deleteAllGrades()
}
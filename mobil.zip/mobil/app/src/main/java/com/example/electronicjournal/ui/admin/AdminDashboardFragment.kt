package com.example.electronicjournal.ui.admin

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.electronicjournal.R
import com.example.electronicjournal.databinding.FragmentAdminDashboardBinding
import com.example.electronicjournal.data.model.User
import com.example.electronicjournal.data.repository.UserRepository
import com.example.electronicjournal.data.model.Schedule
import com.example.electronicjournal.data.repository.ScheduleRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AdminDashboardFragment : Fragment() {

    private var _binding: FragmentAdminDashboardBinding? = null
    private val binding get() = _binding!!

    private lateinit var userRepository: UserRepository
    private lateinit var scheduleRepository: ScheduleRepository

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminDashboardBinding.inflate(inflater, container, false)
        userRepository = UserRepository(requireContext())
        scheduleRepository = ScheduleRepository(requireContext())

        setupListeners()
        return binding.root
    }

    private fun setupListeners() {
        binding.btnAddUser.setOnClickListener { showAddUserDialog() }
        binding.btnDeleteUser.setOnClickListener { showDeleteUserDialog() }
        binding.btnAddLesson.setOnClickListener { showAddLessonDialog() }
        binding.btnDeleteLesson.setOnClickListener { showDeleteLessonDialog() }
    }

    private fun showAddUserDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_user, null)
        val edtLogin = view.findViewById<EditText>(R.id.edtLogin)
        val edtPass = view.findViewById<EditText>(R.id.edtPassword)
        val edtRole = view.findViewById<EditText>(R.id.edtRole)

        AlertDialog.Builder(requireContext())
            .setTitle("Добавить пользователя")
            .setView(view)
            .setPositiveButton("Добавить") { _, _ ->
                val login = edtLogin.text.toString().trim()
                val pass = edtPass.text.toString().trim()
                val role = edtRole.text.toString().trim().ifEmpty { "student" }
                if (login.isNotEmpty() && pass.isNotEmpty()) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        userRepository.addUser(User(login = login, password = pass, userType = role))
                        launch(Dispatchers.Main) {
                            Toast.makeText(requireContext(), "Пользователь добавлен", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showDeleteUserDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_delete_user, null)
        val edtLogin = view.findViewById<EditText>(R.id.edtLoginDelete)

        AlertDialog.Builder(requireContext())
            .setTitle("Удалить пользователя")
            .setView(view)
            .setPositiveButton("Удалить") { _, _ ->
                val login = edtLogin.text.toString().trim()
                if (login.isNotEmpty()) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        userRepository.deleteUser(login)
                        launch(Dispatchers.Main) {
                            Toast.makeText(requireContext(), "Пользователь удалён", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showAddLessonDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_lesson, null)
        val edtSubj = view.findViewById<EditText>(R.id.edtSubject)
        val edtNum = view.findViewById<EditText>(R.id.edtLessonNumber)
        val edtRoom = view.findViewById<EditText>(R.id.edtRoom)

        AlertDialog.Builder(requireContext())
            .setTitle("Добавить пару")
            .setView(view)
            .setPositiveButton("Добавить") { _, _ ->
                val subj = edtSubj.text.toString().trim()
                val num = edtNum.text.toString().toIntOrNull() ?: 1
                val room = edtRoom.text.toString().trim()
                lifecycleScope.launch(Dispatchers.IO) {
                    scheduleRepository.addLesson(Schedule(0, num, subj, room))
                    launch(Dispatchers.Main) {
                        Toast.makeText(requireContext(), "Пара добавлена", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showDeleteLessonDialog() {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_delete_lesson, null)
        val edtId = view.findViewById<EditText>(R.id.edtLessonId)

        AlertDialog.Builder(requireContext())
            .setTitle("Удалить пару")
            .setView(view)
            .setPositiveButton("Удалить") { _, _ ->
                val id = edtId.text.toString().toIntOrNull() ?: -1
                if (id > 0) {
                    lifecycleScope.launch(Dispatchers.IO) {
                        scheduleRepository.deleteLesson(id)
                        launch(Dispatchers.Main) {
                            Toast.makeText(requireContext(), "Пара удалена", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

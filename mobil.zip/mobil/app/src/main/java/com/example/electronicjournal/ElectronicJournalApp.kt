package com.example.electronicjournal

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class ElectronicJournalApp : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Канал для уведомлений об оценках
            val gradesChannel = NotificationChannel(
                GRADES_CHANNEL_ID,
                "Новые оценки",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомления о новых оценках"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }

            // Канал для уведомлений о домашних заданиях
            val homeworkChannel = NotificationChannel(
                HOMEWORK_CHANNEL_ID,
                "Домашние задания",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Уведомления о новых домашних заданиях"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 100, 300)
            }

            notificationManager.createNotificationChannels(
                listOf(gradesChannel, homeworkChannel)
            )
        }
    }

    companion object {
        const val GRADES_CHANNEL_ID = "grades_channel"
        const val HOMEWORK_CHANNEL_ID = "homework_channel"

        lateinit var instance: ElectronicJournalApp
            private set
    }
}
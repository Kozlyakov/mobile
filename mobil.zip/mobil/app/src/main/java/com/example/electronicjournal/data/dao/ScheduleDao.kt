package com.example.electronicjournal.data.dao

import androidx.room.*
import com.example.electronicjournal.data.model.Schedule
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {

    @Query("SELECT * FROM schedule WHERE classId = :classId AND dayOfWeek = :dayOfWeek ORDER BY lessonNumber")
    fun getScheduleByClassAndDay(classId: Int, dayOfWeek: Int): Flow<List<Schedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: Schedule)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSchedules(schedules: List<Schedule>)

    @Query("DELETE FROM schedule")
    suspend fun deleteAllSchedules()
}
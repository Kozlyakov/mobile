package com.example.electronicjournal.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "schedule")
data class Schedule(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val classId: Int,
    val subjectId: Int,
    val dayOfWeek: Int, // 1-понедельник, 6-суббота
    val lessonNumber: Int,
    val room: String? = null
)
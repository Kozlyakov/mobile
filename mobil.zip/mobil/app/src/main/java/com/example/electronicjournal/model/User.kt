package com.example.electronicjournal.model

data class User(
    val id: Int = 0,
    val login: String,
    val firstName: String,
    val lastName: String,
    val userType: String, // "student", "parent", "teacher"
    val className: String? = null,
    val email: String? = null,
    val phone: String? = null
)
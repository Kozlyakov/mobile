package com.example.electronicjournal.model

data class Homework(
    val id: Int = 0,
    val subject: String,
    val description: String,
    val dueDate: String,
    val assignmentDate: String,
    val isCompleted: Boolean = false
)
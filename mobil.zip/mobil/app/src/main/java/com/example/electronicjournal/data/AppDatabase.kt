package com.example.electronicjournal.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.electronicjournal.data.dao.*
import com.example.electronicjournal.data.model.*

@Database(
    entities = [
        User::class,
        Subject::class,
        Grade::class,
        Schedule::class,
        Homework::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun subjectDao(): SubjectDao
    abstract fun gradeDao(): GradeDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun homeworkDao(): HomeworkDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "electronic_journal.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}